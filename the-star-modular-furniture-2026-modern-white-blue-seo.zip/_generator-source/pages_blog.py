from generate import *
import json

with open(os.path.join(ROOT_OUT, "data", "blog.json")) as f:
    POSTS = json.load(f)

ARTICLE_BODY = {
    "indian-vs-international-interior-design": """
<p>A contemporary interior does not have to choose between Indian functionality and an international visual language. The strongest projects usually combine both: practical storage and appliance planning for the way people actually live, with cleaner proportions, restrained materials and carefully controlled lighting.</p>
<h2>Start with lifestyle, not a style label</h2>
<p>Indian homes often need more storage, larger cooking appliances, utility planning and flexible family-use spaces. Lock these requirements first, then use colour, hardware, lighting and material repetition to create the visual character.</p>
<h2>Use a restrained material palette</h2>
<p>For a globally contemporary look, two or three dominant materials are often enough. A neutral base, one wood or stone note and a controlled accent can make kitchens and wardrobes feel cohesive without becoming visually busy.</p>
<h2>Lighting is part of the architecture</h2>
<p>Layer ambient, task and accent lighting. Under-cabinet illumination, wardrobe profile lighting and warm decorative layers can make a practical Indian layout feel much more refined.</p>
<h2>Keep local practicality visible in the details</h2>
<p>Choose finishes that suit the project's cleaning routine, climate and maintenance expectations. Storage for appliances, crockery, spices, cleaning supplies and daily-use items should be resolved before the final aesthetic is approved.</p>
""",
    "2026-modular-kitchen-trends-india-global": """
<p>Kitchen design in 2026 is moving toward quieter visual language and better integration: fewer visual breaks, more concealed storage, layered lighting and materials selected for both appearance and everyday use.</p>
<h2>Handleless and integrated details</h2>
<p>Handleless profiles, recessed pulls and integrated appliance fronts create a cleaner elevation, especially in open-plan homes where the kitchen is visible from the living area.</p>
<h2>Layered lighting</h2>
<p>Ceiling lighting alone is rarely enough. Combine ambient illumination with under-cabinet task lighting and focused accent lighting for display shelves or tall units.</p>
<h2>Storage designed around appliances</h2>
<p>Plan the mixer, microwave, oven, refrigerator, water purifier and smaller countertop appliances before finalising cabinet dimensions. This prevents valuable counter space from becoming permanent storage.</p>
<h2>Finish selection with maintenance in mind</h2>
<p>Glossy acrylic can deliver a reflective premium appearance, while matte and textured laminates offer a wider range of tactile and wood-inspired options. The best choice depends on the room, lighting, usage and maintenance expectations.</p>
""",
    "interior-design-for-nri-projects": """
<p>Remote interior projects need a more documented workflow than a typical local project. When the client, designer and execution team are in different cities or countries, clarity around drawings, dimensions, finishes, approvals and site updates becomes part of the design process.</p>
<h2>Freeze the brief early</h2>
<p>Start with a room-by-room scope, dimensions, appliance list, preferred finishes and budget range. A clear brief reduces revisions later.</p>
<h2>Use an approval pack</h2>
<p>Keep one structured package containing elevations, 3D views, material codes, hardware selections and key dimensions. Number revisions so everyone is working from the same approval.</p>
<h2>Document every finish</h2>
<p>For remote approvals, names such as “white acrylic” are not enough. Record the exact finish family, texture, sheen, colour reference and supplier or sample reference where available.</p>
<h2>Coordinate site execution in stages</h2>
<p>Break installation into measurable stages: site readiness, delivery, carcass installation, shutters and hardware, lighting, final alignment and snagging. Photo and video updates can then be mapped to each stage.</p>
""",
    "acrylic-vs-laminate-kitchen": """
<p>Shutter material is usually the first decision in a kitchen project, because it sets the budget and the look for everything else. Acrylic and laminate are the two finishes we're asked to compare most often — both can look premium, but they behave differently day to day.</p>

<h2>Surface and look</h2>
<p>Acrylic is a high-gloss, mirror-like surface with real depth — light reflects off it in a way printed laminate can't quite match, which is why it's popular for handleless, minimal kitchens. Laminate is available in matte, textured and gloss finishes, including wood-grain and stone-effect prints, and reads slightly less reflective in person than acrylic.</p>

<h2>Maintenance</h2>
<p>Acrylic shows fingerprints and water spots more readily and needs a microfiber wipe-down to stay streak-free, particularly near the hob and sink. Laminate is more forgiving of daily marks and is easier to keep looking clean with normal wiping.</p>

<h2>Durability</h2>
<p>Both are durable when fitted correctly, but they respond differently to impact. Laminate resists chipping at the edges well when edge-banded properly. Acrylic can show fine scratches over years of heavy use near cutting or prep zones, though this is rarely visible unless you look closely under direct light.</p>

<h2>Cost</h2>
<p>Acrylic shutters typically cost more than laminate for a comparable size, largely due to the material and the finishing process. Laminate offers a wider range of looks — including wood and stone effects — at a lower price point, which is why it remains the most-used finish in Indian kitchens.</p>

<h2>Which should you choose?</h2>
<p>If a glossy, handleless, monochrome look is the goal and you're comfortable wiping the surface regularly, acrylic delivers that finish well. If you want a wider choice of textures — including wood-grain — with lower day-to-day maintenance, laminate is usually the more practical choice. Either way, ask to see both finishes under your own kitchen's lighting before deciding; the difference is much easier to judge in person than in a catalogue.</p>
""",
    "modular-wardrobe-planning-guide": """
<p>Most people choose a wardrobe by its shutter finish first — glass, laminate, high-gloss — but the part that decides whether it actually works every morning is the internal layout. Getting that right before production begins saves a lot of frustration later.</p>

<h2>Start with what you own, not a standard template</h2>
<p>A standard wardrobe interior splits space evenly between hanging and shelving. But if you wear mostly folded clothes, that wastes hanging height; if you hang most things, standard shelving is often too shallow or too deep. Before finalising a layout, roughly count what you're storing — long-hang items, short-hang items, folded stacks, accessories — and size each zone to match.</p>

<h2>Plan for the things that don't fold well</h2>
<p>Trousers, scarves, belts and jewellery are usually the first things to end up in a drawer they don't fit properly. Pull-out trouser racks, accessory trays and a shallow jewellery drawer near eye level solve this without needing extra shutters or floor space — they fit inside a standard wardrobe carcass.</p>

<h2>Decide between sliding and hinged doors early</h2>
<p>Sliding doors suit narrower rooms where a hinged door's swing would eat into walking space, and they give a cleaner, more contemporary front. Hinged doors give full access to the entire wardrobe width at once, which some people prefer for daily use. This decision affects the internal layout too, since sliding systems need a small amount of extra depth for the door track.</p>

<h2>Light the inside, not just the room</h2>
<p>A wardrobe is often the darkest storage in a bedroom. Profile lighting fitted inside the columns — particularly behind a glass-front shutter — makes it far easier to find things without switching on the room's main light.</p>

<h2>Walk-in vs. built-in</h2>
<p>A walk-in configuration works well when there's a dedicated 6x6 ft (or larger) area to give over entirely to storage; it allows open bays on more than one wall and room to dress inside the space itself. A built-in wardrobe along one wall is the more space-efficient choice for smaller bedrooms.</p>

<p>Whichever direction you're leaning, it's worth sketching your own rough layout — even on paper — before your first consultation. It gives us a starting point that's specific to what you actually own, rather than a generic template.</p>
""",
    "modular-kitchen-layout-mistakes": """
<p>A modular kitchen can look complete in a 3D render and still be frustrating to cook in once it's installed. Most of the layout problems we're asked to fix later trace back to a handful of avoidable mistakes made early in planning.</p>

<h2>1. Ignoring the work triangle</h2>
<p>The distance between the sink, stove and refrigerator still matters, even in a compact kitchen. Placing these three points too far apart — or in a straight line that forces you to walk the full length of the kitchen repeatedly — adds unnecessary movement to every meal.</p>

<h2>2. Too little landing space next to the hob</h2>
<p>Hot pans need somewhere to go immediately after coming off the stove. A layout without at least some counter space directly beside the hob forces hot cookware onto a far counter or a trivet balanced awkwardly — a small but constant inconvenience.</p>

<h2>3. Underestimating storage for small appliances</h2>
<p>Mixers, toasters and other countertop appliances are often left out of the initial layout and end up cluttering the worktop. Planning a dedicated appliance garage or a pull-out shelf for these during design avoids this later.</p>

<h2>4. Placing the tall unit in the wrong spot</h2>
<p>A full-height larder or oven tower blocks natural light and sightlines if placed at the end of an L-shaped run facing a window. Positioning it at the entry point of the kitchen, or against a blank wall, usually works better for both light and traffic flow.</p>

<h2>5. Not planning for the bin and everyday clutter</h2>
<p>Where the waste bin, cutting boards and daily-use items live is rarely decided until after installation — by which point there's no drawer left for them. Deciding this during the layout stage, not after, means a pull-out bin unit or a dedicated drawer can be built in rather than added on.</p>

<p>Most of these are easy to catch on paper before production starts, which is why we walk through the full layout — appliance placement, storage zones and daily habits — before finalising a quotation.</p>
""",
}


def build_blog_listing():
    root = rel(1)
    body = hero("BLOG", "Interior ideas &amp; guides", "Practical notes on modular kitchens, wardrobes and materials — written from projects we've built.",
        "", PROJECTS[1]["images"][0]["lg"], root, tall=False, breadcrumbs=[("Home","."),("Blog", None)])
    body += f"""
<section class="bg-white">
  <div class="container">
    <div class="blog-grid" data-blog-grid><div class="loading-state">Loading articles&hellip;</div></div>
  </div>
</section>"""
    html = page("Blog | Modular Kitchen &amp; Wardrobe Ideas | The Star Modular Furniture",
        "Guides and ideas on modular kitchens, wardrobes and materials from The Star Modular Furniture, Rajkot.",
        "blog/", "blog/", body, root_depth=1, og_image=PROJECTS[1]["images"][0]["md"])
    write("blog/index.html", html)


def build_blog_posts():
    for post in POSTS:
        root = rel(2)
        content = ARTICLE_BODY[post["slug"]]
        body = f"""
<section class="page-hero" style="min-height:36vh;">
  <div class="hero-media"><img src="{root}{post['image'].replace('-md.webp','-lg.webp')}" alt="" width="1600" height="1000"></div>
  <div class="hero-scrim"></div>
  <nav class="breadcrumbs"><a href="{root}.">Home</a><span>/</span><a href="{root}blog/">Blog</a><span>/</span><span>{post['title']}</span></nav>
  <div class="container hero-content">
    <p class="hero-eyebrow"><span class="dot"></span>{post['category']}</p>
    <h1 style="max-width:26ch;">{post['title']}</h1>
  </div>
</section>
<section class="bg-white">
  <div class="container">
    <div class="prose">
      <p class="small" style="margin-bottom:28px;">By {post['author']} &middot; {post['date']}</p>
      {content}
    </div>
  </div>
</section>
<section class="bg-paper2 final-cta">
  <div class="container">
    <span class="eyebrow">HAVE A PROJECT IN MIND?</span>
    <h2 style="margin-top:16px;">Let's talk about your space.</h2>
    <div class="actions">
      <a class="btn btn-primary" href="{root}contact/">Get a Consultation</a>
    </div>
  </div>
</section>"""
        schema = {
            "@context": "https://schema.org",
            "@type": "Article",
            "headline": post["title"],
            "author": {"@type": "Organization", "name": SITE_NAME},
            "datePublished": post["date"],
            "image": f"{SITE_URL}/{post['image']}",
            "publisher": {"@type": "Organization", "name": SITE_NAME},
        }
        html = page(f"{post['title']} | The Star Modular Furniture",
            post["excerpt"], f"blog/{post['slug']}/", "blog/", body, root_depth=2,
            og_image=post["image"], schema=schema)
        write(f"blog/{post['slug']}/index.html", html)
