from generate import *

def build_contact():
    root = rel(1)
    body = hero("GET IN TOUCH", "Let's discuss your project.", "Visit our Tagore Road showroom, call, or send us your requirement below.",
        "", PROJECTS[3]["images"][0]["lg"], root, tall=False, breadcrumbs=[("Home","."),("Contact", None)])

    body += f"""
<section class="bg-white">
  <div class="container contact-wrap">
    <div>
      <span class="eyebrow">CONTACT DETAILS</span>
      <h2 style="margin-top:10px;">Visit, call or write to us.</h2>
      <ul class="contact-info" style="margin-top:28px;">
        <li>{ICONS['pin']}<div><b>Showroom Address</b><br>{ADDRESS_LINES[0]} {ADDRESS_LINES[1]}<br>{ADDRESS_LINES[2]}</div></li>
        <li>{ICONS['phone']}<div><b>Phone / WhatsApp</b><br><a href="tel:{PHONE_INTL}">{PHONE_DISPLAY}</a> &middot; <a href="tel:+919601511124">{PHONE2_DISPLAY}</a></div></li>
        <li>{ICONS['mail']}<div><b>Email</b><br><a href="mailto:{EMAIL}">{EMAIL}</a></div></li>
        <li>{ICONS['clock']}<div><b>Showroom Hours</b><br>Monday&ndash;Saturday, 10:00 AM&ndash;7:30 PM</div></li>
      </ul>
      <div class="social-links" style="margin-top:26px;">
        <a href="{INSTAGRAM}" target="_blank" rel="noopener">{ICONS['insta']}Instagram</a>
        <a href="{YOUTUBE}" target="_blank" rel="noopener">{ICONS['yt']}YouTube</a>
        <a href="{FACEBOOK}" target="_blank" rel="noopener">{ICONS['fb']}Facebook</a>
      </div>
      <div class="map-embed">
        <iframe src="https://www.google.com/maps?q={ADDRESS_ONE_LINE.replace(' ', '+')}&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="The Star Modular Furniture showroom location"></iframe>
      </div>
    </div>
    <div>
      <span class="eyebrow">REQUEST A QUOTE</span>
      <h2 style="margin-top:10px;">Tell us about your project.</h2>
      <form class="form-grid" style="margin-top:24px;" data-lead-form>
        <div class="field"><label for="name">Full Name</label><input id="name" name="name" required></div>
        <div class="field"><label for="phone">Phone</label><input id="phone" name="phone" type="tel" required></div>
        <div class="field"><label for="email">Email</label><input id="email" name="email" type="email"></div>
        <div class="field"><label for="city">City</label><input id="city" name="city"></div>
        <div class="field"><label for="project_type">Project Type</label>
          <select id="project_type" name="project_type">
            <option value="">Select&hellip;</option>
            <option>Modular Kitchen</option>
            <option>Modular Wardrobe</option>
            <option>Modular Furniture</option>
            <option>Full Interior</option>
            <option>Commercial Project</option>
          </select>
        </div>
        <div class="field"><label for="budget">Budget Range</label>
          <select id="budget" name="budget">
            <option value="">Select&hellip;</option>
            <option>Under &#8377;2 lakh</option>
            <option>&#8377;2&ndash;5 lakh</option>
            <option>&#8377;5&ndash;10 lakh</option>
            <option>Above &#8377;10 lakh</option>
          </select>
        </div>
        <div class="field full"><label for="message">Message</label><textarea id="message" name="message" placeholder="Tell us about your space, timeline or drawings"></textarea></div>
        <div class="field full">
          <button class="btn btn-primary btn-block" type="submit">Send via WhatsApp</button>
          <p class="small" data-form-status hidden style="margin-top:10px;"></p>
          <p class="small" style="margin-top:10px;">Prefer email? Write to us at <a href="mailto:{EMAIL}" style="color:var(--blue);">{EMAIL}</a>.</p>
        </div>
      </form>
    </div>
  </div>
</section>"""

    schema = {
        "@context": "https://schema.org",
        "@type": "ContactPage",
        "url": f"{SITE_URL}/contact/",
    }
    html = page("Contact The Star Modular Furniture | Rajkot Showroom, Phone &amp; WhatsApp",
        "Contact The Star Modular Furniture — visit our Tagore Road showroom in Rajkot, call, WhatsApp, or request a quote online.",
        "contact/", "contact/", body, root_depth=1, og_image=PROJECTS[3]["images"][0]["md"], schema=schema)
    write("contact/index.html", html)


LEGAL_PAGES = {
    "privacy-policy": {
        "title": "Privacy Policy",
        "eyebrow": "LEGAL",
        "body": f"""
<p><strong>Last updated:</strong> September 2026</p>
<p>The Star Modular Furniture ("we", "us", "our") respects your privacy. This page explains what information we collect through thestarmodular.in and how it is used.</p>
<h2>Information We Collect</h2>
<p>When you submit an enquiry, contact form or quote request, we may collect your name, phone number, email address, city, project details and any message or drawings you choose to share. We do not require you to create an account to browse this website.</p>
<h2>How We Use It</h2>
<p>Information submitted through our contact and quote forms is used only to respond to your enquiry, prepare an estimation, and coordinate any project you choose to proceed with. We do not sell or rent your information to third parties.</p>
<h2>WhatsApp &amp; Phone Communication</h2>
<p>Where you contact us via WhatsApp or phone, that conversation is subject to WhatsApp's and your mobile carrier's own privacy terms in addition to this policy.</p>
<h2>Cookies &amp; Analytics</h2>
<p>This website may use standard analytics tools (such as Google Analytics) to understand overall site usage. These tools use cookies and do not identify you personally unless you have submitted a form.</p>
<h2>Data Retention</h2>
<p>Enquiry and project information is retained for as long as reasonably needed to respond to your request or deliver a project, and is deleted or anonymised thereafter unless we are required to keep it for legal or accounting reasons.</p>
<h2>Your Choices</h2>
<p>You may ask us to update or delete personal information you have shared with us by writing to {EMAIL}.</p>
<h2>Contact</h2>
<p>Questions about this policy can be sent to {EMAIL} or {PHONE_DISPLAY}.</p>
""",
    },
    "terms-conditions": {
        "title": "Terms &amp; Conditions",
        "eyebrow": "LEGAL",
        "body": f"""
<p><strong>Last updated:</strong> September 2026</p>
<p>These terms govern your use of thestarmodular.in, operated by The Star Modular Furniture, Rajkot.</p>
<h2>Website Content</h2>
<p>Project photography, descriptions and material information on this website reflect completed work and are provided for reference. Actual finishes may vary slightly from screen representations due to display settings and lighting.</p>
<h2>Quotations</h2>
<p>Quotations shared in person, by email or via WhatsApp are estimates based on the information and drawings provided at the time, and are subject to site measurement and final confirmation before production begins.</p>
<h2>Enquiries &amp; Orders</h2>
<p>Submitting an enquiry through this website does not constitute a binding order. A project is confirmed only once both parties agree to a final quotation and payment terms.</p>
<h2>Intellectual Property</h2>
<p>Project photography, the Star logo and website content belong to The Star Modular Furniture and may not be reproduced without permission.</p>
<h2>Limitation of Liability</h2>
<p>While we take care to keep information on this website accurate, we do not guarantee it is free of errors or omissions, and recommend confirming project-specific details directly with our team.</p>
<h2>Governing Law</h2>
<p>These terms are governed by the laws of India, with jurisdiction in Rajkot, Gujarat.</p>
<h2>Contact</h2>
<p>Questions about these terms can be sent to {EMAIL}.</p>
""",
    },
}

def build_legal_pages():
    for slug, d in LEGAL_PAGES.items():
        root = rel(1)
        body = hero(d["eyebrow"], d["title"], "", "", PROJECTS[0]["images"][0]["lg"], root, tall=False,
            breadcrumbs=[("Home","."),(d["title"], None)])
        body += f'<section class="bg-white"><div class="container prose">{d["body"]}</div></section>'
        html = page(f"{d['title']} | The Star Modular Furniture", f"{d['title']} for The Star Modular Furniture and thestarmodular.in.",
            f"{slug}/", "", body, root_depth=1, og_image=PROJECTS[0]["images"][0]["md"])
        write(f"{slug}/index.html", html)


def build_sitemap_page():
    root = rel(1)
    body = hero("SITE INDEX", "Sitemap", "", "", PROJECTS[1]["images"][0]["lg"], root, tall=False,
        breadcrumbs=[("Home","."),("Sitemap", None)])
    groups = {
        "Main Pages": [("Home","."),("About","about/"),("Projects","projects/"),("Our Process","our-process/"),("Materials & Finishes","materials-finishes/"),("Blog","blog/"),("Contact","contact/")],
        "Services": [("Modular Kitchens","modular-kitchens/"),("Modular Wardrobes","modular-wardrobes/"),("Modular Furniture","modular-furniture/"),("Interior Solutions","interior-solutions/")],
        "For Professionals": [("For Interior Designers","for-interior-designers/"),("For Architects","for-architects/")],
        "Local": [("Modular Kitchen, Rajkot","modular-kitchen-rajkot/"),("Modular Wardrobe, Rajkot","modular-wardrobe-rajkot/"),("Modular Furniture, Rajkot","modular-furniture-rajkot/")],
        "Projects": [(p["title"], f"projects/{p['slug']}/") for p in PROJECTS],
        "Blog": [(b["title"], f"blog/{b['slug']}/") for b in __import__("json").load(open(os.path.join(ROOT_OUT,"data","blog.json")))],
        "Legal": [("Privacy Policy","privacy-policy/"),("Terms & Conditions","terms-conditions/")],
    }
    cols = "".join(
        f'<div class="footer-col" style="color:var(--ink);"><h4 style="color:var(--ink);">{g}</h4><ul>{"".join(f"<li><a href=\"{root}{href}\" style=\"color:var(--blue);\">{label}</a></li>" for label,href in items)}</ul></div>'
        for g, items in groups.items()
    )
    body += f'<section class="bg-white"><div class="container"><div class="footer-grid" style="border:none;grid-template-columns:repeat(4,1fr);">{cols}</div></div></section>'
    html = page("Sitemap | The Star Modular Furniture", "Full page index for thestarmodular.in.", "sitemap/", "", body, root_depth=1, og_image=PROJECTS[1]["images"][0]["md"])
    write("sitemap/index.html", html)


LOCATION_PAGES = {
    "modular-kitchen-rajkot": {
        "h1": "Modular Kitchen, Rajkot",
        "eyebrow": "MODULAR KITCHEN &middot; RAJKOT",
        "lede": "Custom modular kitchens designed, manufactured and installed from our Tagore Road facility in Rajkot.",
        "img": PROJECTS[0]["images"][0]["lg"],
        "body": """
<p>The Star Modular Furniture designs and manufactures modular kitchens from our facility on Tagore Road, Rajkot, serving homes across the city including areas near Bhaktinagar, Kalawad Road, University Road and Mavdi. Every kitchen is built to the client's own layout — L-shape, U-shape, parallel or island — in acrylic, PU paint, glass or high-gloss laminate finishes.</p>
<p>Because manufacturing and installation both happen locally, site visits, material sampling at our Tagore Road showroom, and installation scheduling are all handled without the delays of an out-of-town vendor.</p>
""",
        "seo_title": "Modular Kitchen in Rajkot | Custom Design &amp; Installation | The Star Modular Furniture",
        "seo_desc": "Modular kitchen design, manufacturing and installation in Rajkot, Gujarat by The Star Modular Furniture — visit our Tagore Road showroom.",
    },
    "modular-wardrobe-rajkot": {
        "h1": "Modular Wardrobe, Rajkot",
        "eyebrow": "MODULAR WARDROBE &middot; RAJKOT",
        "lede": "Sliding, hinged and walk-in wardrobe systems designed and installed for homes across Rajkot.",
        "img": PROJECTS[2]["images"][0]["lg"],
        "body": """
<p>From our Tagore Road facility, The Star Modular Furniture builds sliding-door, hinged-door and walk-in wardrobe systems for homes across Rajkot. Internal layouts are planned around how each client actually dresses — hanging bays, pull-out accessory racks, shelving and drawer zones — before a shutter finish is chosen.</p>
<p>Local manufacturing means wardrobe hardware, glass-front shutters and profile lighting can all be sampled at our showroom before production begins.</p>
""",
        "seo_title": "Modular Wardrobe in Rajkot | Sliding &amp; Walk-In Wardrobes | The Star Modular Furniture",
        "seo_desc": "Modular wardrobe design and installation in Rajkot, Gujarat — sliding, hinged and walk-in systems by The Star Modular Furniture.",
    },
    "modular-furniture-rajkot": {
        "h1": "Modular Furniture, Rajkot",
        "eyebrow": "MODULAR FURNITURE &middot; RAJKOT",
        "lede": "Custom TV units, crockery units and bespoke furniture manufactured locally in Rajkot.",
        "img": PROJECTS[1]["images"][0]["lg"],
        "body": """
<p>Alongside kitchens and wardrobes, The Star Modular Furniture manufactures custom furniture pieces — TV units, crockery units, study furniture and bespoke pieces — for homes and offices across Rajkot, matched in material and finish to the rest of the interior.</p>
""",
        "seo_title": "Custom Modular Furniture in Rajkot | The Star Modular Furniture",
        "seo_desc": "Custom modular furniture manufacturing in Rajkot, Gujarat — TV units, crockery units and bespoke furniture by The Star Modular Furniture.",
    },
}

def build_location_pages():
    for slug, d in LOCATION_PAGES.items():
        root = rel(1)
        body = hero(d["eyebrow"], d["h1"], d["lede"], f'<a class="btn btn-primary" href="{root}contact/">Get a Consultation</a>', d["img"], root, tall=False,
            breadcrumbs=[("Home","."),(d["h1"], None)])
        body += f'<section class="bg-white"><div class="container prose">{d["body"]}</div></section>'
        body += f"""
<section class="bg-paper2">
  <div class="container">
    {section_head("RELATED", "Explore more")}
    <div class="project-grid" data-featured-projects data-count="3"></div>
  </div>
</section>"""
        schema = {
            "@context": "https://schema.org",
            "@type": "LocalBusiness",
            "name": SITE_NAME,
            "address": {"@type": "PostalAddress", "streetAddress": "Silver Chambers, Tagore Road", "addressLocality": "Rajkot", "addressRegion": "Gujarat", "postalCode": "360002", "addressCountry": "IN"},
            "telephone": PHONE_INTL,
            "areaServed": "Rajkot",
        }
        html = page(d["seo_title"], d["seo_desc"], f"{slug}/", "", body, root_depth=1, og_image=d["img"].replace("-lg.webp","-md.webp"), schema=schema)
        write(f"{slug}/index.html", html)


def build_404():
    root = "./"
    body = f"""
<section class="bg-white">
  <div class="container error-page">
    <span class="code">404</span>
    <h1 style="margin-top:8px;">Page not found.</h1>
    <p class="lede" style="margin-top:14px;">The page you're looking for may have moved. Try the homepage, or explore our projects.</p>
    <div style="margin-top:28px;display:flex;gap:14px;">
      <a class="btn btn-primary" href="{root}">Go to Homepage</a>
      <a class="btn btn-outline" href="{root}projects/">View Projects</a>
    </div>
  </div>
</section>"""
    html = page("Page Not Found | The Star Modular Furniture", "This page could not be found.", "404/", "", body, root_depth=0, noindex=True)
    write("404.html", html)
