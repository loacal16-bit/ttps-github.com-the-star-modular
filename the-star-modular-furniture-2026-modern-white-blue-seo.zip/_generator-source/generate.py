# -*- coding: utf-8 -*-
"""
Static site generator for The Star Modular Furniture.
Produces a production-ready, SEO-optimised multi-page site into out/.
No build tooling required at runtime — pure HTML/CSS/JS output.
"""
import os, json, re

ROOT_OUT = "out"
SITE_NAME = "The Star Modular Furniture"
SITE_URL = "https://www.thestarmodular.in"  # placeholder — update to live domain
PHONE_DISPLAY = "+91 90164 88859"
PHONE_INTL = "+919016488859"
PHONE2_DISPLAY = "+91 96015 11124"
WHATSAPP = "https://wa.me/919016488859"
EMAIL = "thestarmodularfurniture@gmail.com"
ADDRESS_LINES = ["Silver Chambers, Tagore Road,", "Opposite Atul Motors, Bhaktinagar Station Plot,", "Rajkot, Gujarat 360002, India"]
ADDRESS_ONE_LINE = "Silver Chambers, Tagore Road, Opposite Atul Motors, Bhaktinagar Station Plot, Rajkot, Gujarat 360002"
INSTAGRAM = "https://www.instagram.com/thestarmodularfurniture"
YOUTUBE = "https://youtube.com/@thestarmodularfurniture"
FACEBOOK = "https://www.facebook.com/share/18WaoturzB/"

with open(os.path.join(ROOT_OUT, "data", "projects.json")) as f:
    PROJECTS = json.load(f)

# ---------------------------------------------------------------- icons (inline svg, stroke currentColor)
ICONS = {
    "phone": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 5c0 8.284 6.716 15 15 15l3-3-5-4-2.5 2A13 13 0 0 1 7.5 9.5l2-2.5-4-5-3 3Z" stroke-linejoin="round"/></svg>',
    "whatsapp": '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5.1-1.3A10 10 0 1 0 12 2Zm5.8 14.3c-.3.7-1.5 1.4-2.1 1.5-.6.1-1.2.2-3.9-.9-3.3-1.4-5.4-4.8-5.6-5s-1.3-1.8-1.3-3.4.9-2.4 1.2-2.7c.3-.3.6-.4.9-.4h.6c.2 0 .5-.1.7.6l1 2.4c.1.2.1.4 0 .6l-.5.7c-.2.2-.3.4-.1.7.2.3.9 1.5 2 2.4 1.3 1.1 2.4 1.5 2.8 1.6.3.1.5.1.7-.1l.9-1c.2-.3.5-.2.7-.1l2.1 1c.2.1.4.2.4.4.1.3.1 1-.2 1.7Z"/></svg>',
    "mail": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 6h18v12H3z"/><path d="m3 7 9 6 9-6"/></svg>',
    "pin": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 22s7-7.4 7-12.6A7 7 0 0 0 5 9.4C5 14.6 12 22 12 22Z"/><circle cx="12" cy="9.4" r="2.4"/></svg>',
    "arrow": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
    "insta": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.3" cy="6.7" r="1"/></svg>',
    "yt": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="5" width="20" height="14" rx="4"/><path d="M10 9.5v5l4.5-2.5Z" fill="currentColor" stroke="none"/></svg>',
    "fb": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M15 3h-2a4 4 0 0 0-4 4v3H6v4h3v7h4v-7h3l1-4h-4V7a1 1 0 0 1 1-1h3Z"/></svg>',
    "down": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 4v14M6 12l6 6 6-6"/></svg>',
    "check": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m5 12 5 5L20 7"/></svg>',
    "clock": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></svg>',
    "grid": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>',
}

NAV = [
    ("Home", ""),
    ("About", "about/"),
    ("Modular Kitchens", "modular-kitchens/"),
    ("Modular Wardrobes", "modular-wardrobes/"),
    ("Modular Furniture", "modular-furniture/"),
    ("Interior Solutions", "interior-solutions/"),
    ("Projects", "projects/"),
    ("For Designers", "for-interior-designers/"),
    ("For Architects", "for-architects/"),
    ("Materials", "materials-finishes/"),
    ("Process", "our-process/"),
    ("Blog", "blog/"),
    ("Contact", "contact/"),
]
# Trimmed nav for header (full list used in footer sitemap)
HEADER_NAV = [
    ("Home", ""),
    ("About", "about/"),
    ("Architecture & Interiors", "interior-solutions/"),
    ("Projects", "projects/"),
    ("Blog", "blog/"),
    ("Contact", "contact/"),
]

ARCH_INTERIOR_GROUPS = [
    ("INTERIOR SOLUTIONS", [
        ("Interior Solutions", "interior-solutions/"),
        ("Modular Kitchens", "modular-kitchens/"),
        ("Modular Wardrobes", "modular-wardrobes/"),
        ("Modular Furniture", "modular-furniture/"),
    ]),
    ("DESIGN & PROFESSIONALS", [
        ("For Architects", "for-architects/"),
        ("For Interior Designers", "for-interior-designers/"),
        ("Materials & Finishes", "materials-finishes/"),
        ("Our Process", "our-process/"),
    ]),
]


def rel(path_depth):
    """Relative path prefix to site root, based on folder depth."""
    return "../" * path_depth if path_depth else "./"


def head(title, description, canonical_path, root, og_image="assets/img/og/default-og.jpg", schema=None, noindex=False):
    canonical = SITE_URL + "/" + canonical_path
    robots = "noindex,follow" if noindex else "index,follow"
    schema_tag = f'<script type="application/ld+json">{json.dumps(schema)}</script>' if schema else ""
    return f"""<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{title}</title>
<meta name="description" content="{description}">
<meta name="robots" content="{robots}">
<link rel="canonical" href="{canonical}">
<link rel="icon" href="{root}favicon.ico">
<link rel="apple-touch-icon" href="{root}assets/img/brand/star-mark-180.png">
<meta name="theme-color" content="#0b3cc1">
<meta name="format-detection" content="telephone=no">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{root}assets/css/style.css">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{SITE_NAME}">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{description}">
<meta property="og:url" content="{canonical}">
<meta property="og:image" content="{SITE_URL}/{og_image}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{title}">
<meta name="twitter:description" content="{description}">
<meta name="twitter:image" content="{SITE_URL}/{og_image}">
{schema_tag}"""


def header_html(root, active):
    # Architecture & Interiors is the primary service hub. Keep the visible
    # header compact while exposing the full service architecture in a
    # responsive, accessible dropdown.
    parent_active = active in {
        "interior-solutions/", "modular-kitchens/", "modular-wardrobes/",
        "modular-furniture/", "for-architects/", "for-interior-designers/",
        "materials-finishes/", "our-process/"
    }
    top_links = []
    for label, href in HEADER_NAV:
        if label == "Architecture & Interiors":
            continue
        is_active = href == active
        top_links.append(
            f'<a href="{root}{href}" class="{"active" if is_active else ""}">{label}</a>'
        )
    groups_html = []
    for group_title, items in ARCH_INTERIOR_GROUPS:
        items_html = []
        for label, href in items:
            cls = "active" if href == active else ""
            items_html.append(
                f'<a href="{root}{href}" class="{cls}"><span>{label}</span><small>↗</small></a>'
            )
        groups_html.append(
            f'<div class="nav-mega-col"><span class="nav-mega-label">{group_title}</span>'
            + "".join(items_html) + '</div>'
        )
    mega = "".join(groups_html)
    return f"""<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header">
  <div class="container header-inner">
    <a class="brand" href="{root}">
      <img class="brand-logo-full" src="{root}assets/img/brand/logo-full.png" alt="The Star Modular Furniture" width="190" height="50">
    </a>
    <nav class="main-nav" aria-label="Primary">
      {''.join(top_links)}
      <div class="nav-dropdown {"open-active" if parent_active else ""}">
        <button class="nav-dropdown-toggle" type="button" aria-expanded="false" aria-haspopup="true">
          <span>Architecture &amp; Interiors</span>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
        </button>
        <div class="nav-mega" aria-hidden="true">
          <div class="nav-mega-inner">
            <div class="nav-mega-intro">
              <span class="nav-mega-kicker">DESIGN · DETAIL · DELIVERY</span>
              <strong>Spaces designed around the way you live.</strong>
              <p>Explore kitchens, wardrobes, furniture and complete interior solutions — all under one roof.</p>
              <a href="{root}contact/" class="nav-mega-cta">Start a Project <span>↗</span></a>
            </div>
            {mega}
          </div>
        </div>
      </div>
    </nav>
    <div class="header-cta">
      <a class="header-call" href="tel:{PHONE_INTL}">{ICONS['phone']}<span>{PHONE_DISPLAY}</span></a>
      <a class="btn btn-primary btn-sm header-quote" href="{root}contact/">Get Consultation</a>
      <button class="nav-toggle" aria-label="Menu" aria-expanded="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
      </button>
    </div>
  </div>
</header>
<div class="mobile-bar">
  <a href="tel:{PHONE_INTL}">{ICONS['phone']}Call</a>
  <a class="mb-whats" href="{WHATSAPP}" target="_blank" rel="noopener">{ICONS['whatsapp']}WhatsApp</a>
  <a href="{root}contact/">{ICONS['grid']}Get Quote</a>
</div>"""


def footer_html(root):
    def col(title, items):
        lis = "\n".join(f'<li><a href="{root}{href}">{label}</a></li>' for label, href in items)
        return f'<div class="footer-col"><h4>{title}</h4><ul>{lis}</ul></div>'

    company = col("Company", [("About", "about/"), ("Projects", "projects/"), ("Our Process", "our-process/"), ("Materials & Finishes", "materials-finishes/"), ("Blog", "blog/"), ("Contact", "contact/")])
    services = col("Services", [("Modular Kitchens", "modular-kitchens/"), ("Modular Wardrobes", "modular-wardrobes/"), ("Modular Furniture", "modular-furniture/"), ("Interior Solutions", "interior-solutions/")])
    pro = col("For Professionals", [("Interior Designers", "for-interior-designers/"), ("Architects", "for-architects/"), ("Modular Kitchen, Rajkot", "modular-kitchen-rajkot/"), ("Modular Wardrobe, Rajkot", "modular-wardrobe-rajkot/")])
    return f"""<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <img src="{root}assets/img/brand/star-mark-64.png" alt="{SITE_NAME}" width="36" height="36">
        <p>Premium modular kitchens, wardrobes and custom furniture — designed, manufactured and installed from our Rajkot facility.</p>
        <ul class="footer-contact" style="margin-top:22px;">
          <li>{ICONS['pin']}<span>{ADDRESS_ONE_LINE}</span></li>
        </ul>
        <div style="margin-top:18px;"><a class="btn btn-outline-light btn-sm" href="{root}brochure/The-Star-Modular-Furniture-Brochure.pdf" target="_blank">Download Brochure</a></div>
      </div>
      {company}
      {services}
      <div class="footer-col">
        <h4>Contact</h4>
        <ul class="footer-contact">
          <li>{ICONS['phone']}<span><a href="tel:{PHONE_INTL}">{PHONE_DISPLAY}</a><br><a href="tel:+919601511124">{PHONE2_DISPLAY}</a></span></li>
          <li>{ICONS['mail']}<span><a href="mailto:{EMAIL}">{EMAIL}</a></span></li>
        </ul>
        <div class="social-links" style="margin-top:6px;">
          <a href="{INSTAGRAM}" target="_blank" rel="noopener" aria-label="Instagram">{ICONS['insta']}</a>
          <a href="{YOUTUBE}" target="_blank" rel="noopener" aria-label="YouTube">{ICONS['yt']}</a>
          <a href="{FACEBOOK}" target="_blank" rel="noopener" aria-label="Facebook">{ICONS['fb']}</a>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <span id="year">2026</span> {SITE_NAME}. All rights reserved.</span>
      <div class="flinks">
        <a href="{root}privacy-policy/">Privacy Policy</a>
        <a href="{root}terms-conditions/">Terms &amp; Conditions</a>
        <a href="{root}sitemap/">Sitemap</a>
      </div>
    </div>
  </div>
</footer>
<script>document.getElementById('year').textContent = new Date().getFullYear();</script>
<script src="{root}assets/js/main.js"></script>"""


def page(title, description, canonical_path, active, body, root_depth=0, og_image=None, schema=None, hero_dark=True, noindex=False):
    root = rel(root_depth)
    og = og_image or "assets/img/og/default-og.jpg"
    return f"""<!DOCTYPE html>
<html lang="en" data-root="{root}">
<head>
{head(title, description, canonical_path, root, og, schema, noindex)}
</head>
<body>
{header_html(root, active)}
<main id="main">
{body}
</main>
{footer_html(root)}
</body>
</html>"""


def write(path, html):
    full = os.path.join(ROOT_OUT, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(html)
    print("wrote", full)


# ---------------------------------------------------------------- shared component builders

def hero(eyebrow, h1, lede, actions, image, root, tall=True, breadcrumbs=None):
    crumbs = ""
    if breadcrumbs:
        parts = []
        for label, href in breadcrumbs:
            if href:
                parts.append(f'<a href="{root}{href}">{label}</a>')
            else:
                parts.append(f'<span>{label}</span>')
        crumbs = f'<nav class="breadcrumbs" aria-label="Breadcrumb">{"<span>/</span>".join(parts)}</nav>'
    cls = "hero" if tall else "page-hero"
    scroll = f"""<div class="hero-scroll"><span>SCROLL</span>{ICONS['down']}</div>""" if tall else ""
    return f"""<section class="{cls}">
  <div class="hero-media"><img src="{root}{image}" alt="{h1} — The Star Modular Furniture" width="1600" height="1200" fetchpriority="high" decoding="async"></div>
  <div class="hero-scrim"></div>
  {crumbs}
  <div class="container hero-content">
    <p class="hero-eyebrow"><span class="dot"></span>{eyebrow}</p>
    <h1>{h1}</h1>
    <p class="lede">{lede}</p>
    <div class="hero-actions">{actions}</div>
  </div>
  {scroll}
</section>"""


def section_head(eyebrow, title, lede=None, center=False):
    lede_html = f'<p class="lede" style="margin-top:14px;">{lede}</p>' if lede else ""
    cls = "section-head center" if center else "section-head"
    return f"""<div class="{cls}">
  <span class="eyebrow">{eyebrow}</span>
  <h2>{title}</h2>
  {lede_html}
</div>"""
