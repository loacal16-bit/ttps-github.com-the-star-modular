from generate import *

def build_projects_listing():
    root = rel(1)
    body = hero("PORTFOLIO", "Projects", "A portfolio of modular kitchens, wardrobes and custom furniture, designed and installed across Rajkot.",
        "", PROJECTS[2]["images"][0]["lg"], root, tall=False, breadcrumbs=[("Home","."),("Projects", None)])

    cats = sorted(set(p["category"] for p in PROJECTS))
    chips = '<button class="filter-chip active" data-filter-chip="all">All Projects</button>' + "".join(
        f'<button class="filter-chip" data-filter-chip="{c}">{c}s</button>' for c in cats
    )
    body += f"""
<section class="bg-white">
  <div class="container">
    <div class="project-toolbar">{chips}</div>
    <div class="project-grid" data-project-grid><div class="loading-state">Loading projects&hellip;</div></div>
  </div>
</section>"""

    schema = {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": "Projects | The Star Modular Furniture",
        "url": f"{SITE_URL}/projects/",
    }
    html = page("Projects | Modular Kitchen &amp; Wardrobe Portfolio | The Star Modular Furniture",
        "Browse completed modular kitchen and wardrobe projects by The Star Modular Furniture, Rajkot.",
        "projects/", "projects/", body, root_depth=1, og_image=PROJECTS[2]["images"][0]["md"], schema=schema)
    write("projects/index.html", html)


def build_project_details():
    for i, p in enumerate(PROJECTS):
        root = rel(2)
        hero_img = p["images"][0]["lg"]
        body = hero(p["category"].upper(), p["title"], p["location"], "", hero_img, root, tall=False,
            breadcrumbs=[("Home","."),("Projects","projects/"),(p["title"], None)])

        materials_html = "".join(f'<li>{m}</li>' for m in p["materials"])
        body += f"""
<section class="bg-white">
  <div class="container">
    <div class="pd-meta">
      <div class="m"><span>Category</span><b>{p['category']}</b></div>
      <div class="m"><span>Location</span><b>{p['location']}</b></div>
      <div class="m"><span>Year</span><b>{p['year']}</b></div>
      <div class="m"><span>Client Type</span><b>{p['client_type']}</b></div>
    </div>
    <div class="intro-grid" style="margin-bottom:56px;">
      <div>
        <span class="eyebrow">ABOUT THIS PROJECT</span>
        <h2>{p['title']}</h2>
        <p class="lede" style="margin-top:18px;">{p['description']}</p>
      </div>
      <div>
        <span class="eyebrow">MATERIALS &amp; FINISHES</span>
        <ul class="prose" style="margin-top:14px;list-style:none;">
          {"".join(f'<li style="display:flex;gap:10px;margin-bottom:12px;">{ICONS["check"]}<span>{m}</span></li>' for m in p["materials"])}
        </ul>
      </div>
    </div>
    <div class="pd-gallery" data-pd-gallery="{p['slug']}"></div>
  </div>
</section>
<section class="bg-paper2">
  <div class="container">
    {section_head("MORE PROJECTS", "Related work")}
    <div class="project-grid" data-related-projects></div>
  </div>
</section>
<section class="bg-ink final-cta">
  <div class="container">
    <span class="eyebrow">LIKE WHAT YOU SEE?</span>
    <h2 style="color:#fff;margin-top:16px;">Start a project like this one.</h2>
    <div class="actions">
      <a class="btn btn-primary" href="{root}contact/">Get a Consultation</a>
      <a class="btn btn-whatsapp" href="{WHATSAPP}" target="_blank" rel="noopener">{ICONS['whatsapp']}WhatsApp Us</a>
    </div>
  </div>
</section>"""

        schema = {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [
                {"@type": "ListItem", "position": 1, "name": "Home", "item": SITE_URL + "/"},
                {"@type": "ListItem", "position": 2, "name": "Projects", "item": SITE_URL + "/projects/"},
                {"@type": "ListItem", "position": 3, "name": p["title"], "item": f"{SITE_URL}/projects/{p['slug']}/"},
            ],
        }
        html = page(p["seo_title"], p["seo_description"], f"projects/{p['slug']}/", "projects/", body,
                    root_depth=2, og_image=p["images"][0]["md"], schema=schema)
        write(f"projects/{p['slug']}/index.html", html)


def build_for_designers():
    root = rel(1)
    body = hero("FOR INTERIOR DESIGNERS", "Your Design. Our Manufacturing &amp; Execution.",
        "Share your drawings and specifications — we handle production, delivery and installation, so you can focus on design and client management.",
        f'<a class="btn btn-primary" href="{root}contact/">Discuss Your Upcoming Project</a>',
        PROJECTS[1]["images"][0]["lg"], root, tall=False, breadcrumbs=[("Home","."),("For Interior Designers", None)])

    reasons = [
        ("Zero Manufacturing Headache", "You share the drawing; we take care of production, delivery and installation."),
        ("Designer-Centric Approach", "We work strictly according to your dimensions, material specs and design language."),
        ("Production Support", "In-house manufacturing means changes and clarifications are resolved quickly."),
        ("Transparent Estimation", "A detailed, competitive quotation with a clear material breakdown."),
        ("Material Selection", "Access to acrylic, PU, glass and laminate finishes to match your palette."),
        ("Quality Control", "Every unit is checked against the drawing before it leaves the factory."),
        ("Delivery Coordination", "Delivery scheduled around your site's readiness."),
        ("Professional Installation", "Our own installation team, not a subcontractor."),
        ("Showroom Access", "Bring your clients to our Tagore Road showroom to experience finishes live."),
    ]
    body += f"""
<section class="bg-white">
  <div class="container">
    {section_head("WHY PARTNER WITH THE STAR", "Built for busy design practices")}
    <div class="feature-list">
      {''.join(f'<div class="feature-item"><h4>{t}</h4><p>{d}</p></div>' for t,d in reasons)}
    </div>
  </div>
</section>"""

    steps = ["Share Drawings","Discuss Materials","Receive Estimation","Production","Delivery","Installation"]
    body += f"""
<section class="bg-navy">
  <div class="container">
    <span class="eyebrow" style="color:#8fa0ff;">WORKFLOW</span>
    <h2 style="color:#fff;margin-top:12px;">A six-step working process</h2>
    <ul class="mini-steps" style="margin-top:30px;max-width:640px;">
      {''.join(f'<li><span class="n">{i+1:02d}</span><span>{s}</span></li>' for i,s in enumerate(steps))}
    </ul>
  </div>
</section>"""

    body += f"""
<section class="bg-paper2 final-cta">
  <div class="container">
    <span class="eyebrow">LET'S TALK</span>
    <h2 style="margin-top:16px;">Discuss your upcoming project.</h2>
    <div class="actions">
      <a class="btn btn-primary" href="{root}contact/">Discuss Your Upcoming Project</a>
      <a class="btn btn-outline" href="{root}for-architects/">For Architects</a>
    </div>
  </div>
</section>"""

    html = page("For Interior Designers | Manufacturing &amp; Execution Partner | The Star Modular Furniture",
        "The Star Modular Furniture manufactures and installs to your drawings and specifications — a production and execution partner for interior designers in Rajkot.",
        "for-interior-designers/", "for-interior-designers/", body, root_depth=1, og_image=PROJECTS[1]["images"][0]["md"])
    write("for-interior-designers/index.html", html)


def build_for_architects():
    root = rel(1)
    body = hero("FOR ARCHITECTS", "Collaborate With The Star",
        "Custom dimensions, material specifications and production coordination — executed with quality control and professional installation.",
        f'<a class="btn btn-primary" href="{root}contact/">Collaborate With The Star</a>',
        PROJECTS[3]["images"][0]["lg"], root, tall=False, breadcrumbs=[("Home","."),("For Architects", None)])

    focus = [
        ("Custom Dimensions", "Every unit built to the exact dimensions in your architectural drawing."),
        ("Design Specifications", "Shutter profiles, hardware and finish specified by your documentation."),
        ("Material Specifications", "Acrylic, PU paint, glass and laminate finishes matched to your material schedule."),
        ("Production Coordination", "A single point of contact for production scheduling across a project."),
        ("Project Execution", "Delivery and installation coordinated with your site programme."),
        ("Quality Control", "Every unit checked against specification before dispatch."),
        ("Installation", "Our own installation team, coordinated with other site trades."),
    ]
    body += f"""
<section class="bg-white">
  <div class="container">
    {section_head("WHAT WE FOCUS ON", "Execution that matches your specification")}
    <div class="feature-list">
      {''.join(f'<div class="feature-item"><h4>{t}</h4><p>{d}</p></div>' for t,d in focus)}
    </div>
  </div>
</section>"""

    body += f"""
<section class="bg-ink final-cta">
  <div class="container">
    <span class="eyebrow">PROJECT COORDINATION</span>
    <h2 style="color:#fff;margin-top:16px;">Collaborate with The Star on your next project.</h2>
    <div class="actions">
      <a class="btn btn-primary" href="{root}contact/">Collaborate With The Star</a>
      <a class="btn btn-whatsapp" href="{WHATSAPP}" target="_blank" rel="noopener">{ICONS['whatsapp']}WhatsApp Us</a>
    </div>
  </div>
</section>"""

    html = page("For Architects | Modular Furniture Production Partner | The Star Modular Furniture",
        "The Star Modular Furniture executes modular kitchen, wardrobe and furniture production to architectural specification, with quality control and installation in Rajkot.",
        "for-architects/", "for-architects/", body, root_depth=1, og_image=PROJECTS[3]["images"][0]["md"])
    write("for-architects/index.html", html)


def build_materials():
    root = rel(1)
    body = hero("MATERIALS &amp; FINISHES", "A material library built from real projects.",
        "Acrylic, PU paint, glass, high-gloss laminate, handleless profiles and wardrobe hardware — browse the finishes behind our recent work.",
        "", PROJECTS[0]["images"][2]["lg"], root, tall=False, breadcrumbs=[("Home","."),("Materials &amp; Finishes", None)])

    body += f"""
<section class="bg-white">
  <div class="container">
    <div class="material-grid" data-material-grid><div class="loading-state">Loading materials&hellip;</div></div>
    <p class="small" style="margin-top:28px;">Photos show finishes as used in completed projects. Visit our Tagore Road showroom to see current material samples and colours in person.</p>
  </div>
</section>
<section class="bg-paper2 final-cta">
  <div class="container">
    <span class="eyebrow">SEE FINISHES IN PERSON</span>
    <h2 style="margin-top:16px;">Book a showroom visit.</h2>
    <div class="actions">
      <a class="btn btn-primary" href="{root}contact/">Book a Visit</a>
    </div>
  </div>
</section>"""

    html = page("Materials &amp; Finishes | Modular Kitchen &amp; Wardrobe Finishes | The Star Modular Furniture",
        "Explore acrylic, PU paint, glass, high-gloss laminate and handleless finishes used in modular kitchens and wardrobes by The Star Modular Furniture.",
        "materials-finishes/", "materials-finishes/", body, root_depth=1, og_image=PROJECTS[0]["images"][2]["md"])
    write("materials-finishes/index.html", html)


def build_process():
    root = rel(1)
    body = hero("OUR PROCESS", "How we work together.",
        "A transparent, four-step workflow from first conversation to site installation.",
        "", PROJECTS[2]["images"][1]["lg"], root, tall=False, breadcrumbs=[("Home","."),("Our Process", None)])

    steps = [
        ("01","Share &amp; Discuss","Tell us about your space — send drawings if you have them, along with material and budget preferences. We visit or discuss remotely to understand the layout."),
        ("02","Transparent Estimation","You receive a detailed quotation with a clear, material-by-material breakdown — no hidden line items."),
        ("03","Precision Production","Once approved, your order is manufactured at our Rajkot facility with rigorous quality checks at every stage."),
        ("04","Site Installation","Our own installation team delivers and fits the units, testing every drawer, hinge and shutter before handover."),
    ]
    step_imgs = [PROJECTS[0]["images"][0], PROJECTS[1]["images"][0], PROJECTS[2]["images"][0], PROJECTS[3]["images"][0]]
    body += f"""
<section class="bg-white">
  <div class="container">
    {''.join(f'''<div class="intro-grid" style="margin-bottom:64px;align-items:center;">
      <div><span class="eyebrow">STEP {n}</span><h2 style="margin-top:10px;">{t}</h2><p class="lede" style="margin-top:16px;">{d}</p></div>
      <div><img src="{root}{step_imgs[i]['md']}" alt="{t}" loading="lazy" width="900" height="675" style="aspect-ratio:4/3;object-fit:cover;"></div>
    </div>''' for i,(n,t,d) in enumerate(steps))}
  </div>
</section>"""

    body += f"""
<section class="bg-ink final-cta">
  <div class="container">
    <span class="eyebrow">READY WHEN YOU ARE</span>
    <h2 style="color:#fff;margin-top:16px;">Share &amp; discuss your project.</h2>
    <div class="actions">
      <a class="btn btn-primary" href="{root}contact/">Get a Consultation</a>
    </div>
  </div>
</section>"""

    html = page("Our Process | How The Star Modular Furniture Works | Rajkot",
        "From first conversation to site installation — the four-step process The Star Modular Furniture follows on every project.",
        "our-process/", "our-process/", body, root_depth=1, og_image=PROJECTS[2]["images"][1]["md"])
    write("our-process/index.html", html)
