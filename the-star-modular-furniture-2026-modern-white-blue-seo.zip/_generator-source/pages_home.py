from generate import *

def build_home():
    root = ""
    hero_img = PROJECTS[0]["images"][0]["lg"]  # dual-tone island kitchen, hero shot

    body = hero(
        "RAJKOT &middot; GUJARAT &middot; INTERIOR &amp; MODULAR FURNITURE",
        "Modern spaces. Precisely made.",
        "Premium modular kitchens, wardrobes, furniture and interior solutions — designed for contemporary Indian homes, NRI residences and design-led projects across Gujarat and beyond.",
        f'''<a class="btn btn-primary" href="projects/">Explore Projects</a>
        <a class="btn btn-outline-light" href="contact/">Get a Consultation</a>
        <a class="btn btn-whatsapp" href="{WHATSAPP}" target="_blank" rel="noopener">{ICONS['whatsapp']}WhatsApp Us</a>''',
        hero_img, root
    )

    # B. Trust / brand intro
    body += f"""
<section class="bg-white">
  <div class="container intro-grid">
    <div>
      <span class="eyebrow">ABOUT THE STAR</span>
      <h2>Smart spaces, smart solutions.</h2>
      <p class="lede" style="margin-top:18px;">The Star Modular Furniture designs, manufactures and installs modular kitchens, wardrobes and custom furniture from our facility and experience center on Tagore Road, Rajkot. Every project is built to the client's own dimensions and material specification, then produced with precision engineering and installed by our own site team.</p>
      <div class="stat-row">
        <div class="stat"><b>End-to-End</b><span>Design to installation</span></div>
        <div class="stat"><b>Rajkot</b><span>Manufacturing &amp; showroom</span></div>
        <div class="stat"><b>Custom-Built</b><span>To your drawings &amp; specs</span></div>
      </div>
      <div style="margin-top:36px;"><a class="btn btn-outline" href="about/">More About The Star {ICONS['arrow']}</a></div>
    </div>
    <div>
      <img src="{PROJECTS[2]['images'][0]['md']}" alt="Walk-in wardrobe system by The Star Modular Furniture" loading="lazy" width="900" height="675" style="aspect-ratio:4/3;object-fit:cover;">
    </div>
  </div>
</section>"""

    # C. Services
    services = [
        ("01", "Modular Kitchens", "L-shape, U-shape and island layouts in acrylic, PU, glass and laminate finishes.", "modular-kitchens/"),
        ("02", "Modular Wardrobes", "Sliding, hinged and walk-in wardrobe systems with glass fronts and profile lighting.", "modular-wardrobes/"),
        ("03", "Custom Furniture", "TV units, crockery units and bespoke furniture built to match your interior scheme.", "modular-furniture/"),
        ("04", "Interior Solutions", "Coordinated execution support for full-home and commercial interior projects.", "interior-solutions/"),
    ]
    body += f"""
<section class="bg-paper2">
  <div class="container">
    {section_head("WHAT WE BUILD", "Four ways we work with you")}
    <div class="service-grid">
      {''.join(f'''<a class="service-card" href="{href}">
        <span class="num">{n}</span>
        <div><h3>{t}</h3><p>{d}</p></div>
        <span class="link">Learn more {ICONS['arrow']}</span>
      </a>''' for n,t,d,href in services)}
    </div>
  </div>
</section>"""

    # D. Service area + India / international design guidance
    body += f"""
<section class="bg-blue-soft service-area-section">
  <div class="container">
    <div class="section-split">
      <div class="section-head" style="margin-bottom:0;">
        <span class="eyebrow">RAJKOT · GUJARAT · BEYOND</span>
        <h2>Local execution. International design thinking.</h2>
        <p class="lede" style="margin-top:14px;">We work from Rajkot for residential and commercial interiors across Rajkot and nearby cities, while collaborating with architects, interior designers and NRI clients on detail-driven projects.</p>
      </div>
      <a class="btn btn-primary" href="contact/">Discuss Your Project {ICONS['arrow']}</a>
    </div>
    <div class="area-chips">
      {''.join(f'<span>{x}</span>' for x in ["Rajkot", "Gondal", "Morbi", "Jamnagar", "Jetpur", "Wankaner", "Shapar-Veraval", "Surendranagar", "Junagadh", "Bhavnagar", "Ahmedabad", "Across Gujarat"])}
    </div>
    <div class="design-tips-grid">
      <article class="design-tip"><span class="tip-no">01</span><h3>India-first functionality</h3><p>Plan for Indian cooking habits, appliances, storage-heavy kitchens, utility areas, dust, heat and everyday family use before choosing the finish.</p></article>
      <article class="design-tip"><span class="tip-no">02</span><h3>International visual language</h3><p>Use clean proportions, restrained materials, integrated lighting, handleless details and consistent finishes for a globally contemporary feel.</p></article>
      <article class="design-tip"><span class="tip-no">03</span><h3>NRI &amp; global projects</h3><p>Clear drawings, exact dimensions, material schedules and documented approvals make remote design-to-execution workflows easier to manage.</p></article>
    </div>
  </div>
</section>"""
    # E. Featured Projects
    body += f"""
<section class="bg-white">
  <div class="container">
    <div class="section-split">
      <div class="section-head" style="margin-bottom:0;">
        <span class="eyebrow">RECENT WORK</span>
        <h2>Featured projects</h2>
      </div>
      <a class="btn btn-outline" href="projects/">View All Projects</a>
    </div>
    <div class="project-grid" data-featured-projects data-count="3"><div class="loading-state">Loading projects&hellip;</div></div>
  </div>
</section>"""

    # E. Why The Star
    features = [
        ("Precision Manufacturing", "Every panel is cut and edge-banded to the millimetre against your approved drawing."),
        ("Designer-Centric Approach", "We work strictly to the dimensions, material specs and design language you share with us."),
        ("Transparent Estimation", "A detailed quotation with a clear material-by-material breakdown, before any production begins."),
        ("Professional Installation", "Our own site team handles delivery and installation — clean, coordinated and on schedule."),
        ("Quality Materials", "Acrylic, PU paint, glass, high-gloss laminate and handleless profile hardware from trusted suppliers."),
        ("Timely Execution", "Committed production and installation timelines, tracked from estimation to handover."),
    ]
    body += f"""
<section class="bg-ink">
  <div class="container">
    {section_head("WHY THE STAR", "Built on process, not promises")}
    <div class="feature-list">
      {''.join(f'<div class="feature-item"><h4>{t}</h4><p>{d}</p></div>' for t,d in features)}
    </div>
  </div>
</section>"""

    # F. Designer / Architect collaboration
    body += f"""
<section class="bg-navy" style="padding:0;">
  <div class="split-panel">
    <div class="copy">
      <span class="eyebrow" style="color:#8fa0ff;">FOR DESIGNERS &amp; ARCHITECTS</span>
      <h2 style="color:#fff;">Your Design. Our Execution.</h2>
      <p class="lede">Share your 2D or 3D drawings, dimensions, material specifications and design language — we handle production, delivery and installation, exactly to your specification.</p>
      <ul class="mini-steps">
        <li><span class="n">01</span><span>You share drawings, dimensions and material specs</span></li>
        <li><span class="n">02</span><span>We produce a transparent, itemised estimation</span></li>
        <li><span class="n">03</span><span>Precision production and quality checks in-house</span></li>
        <li><span class="n">04</span><span>Delivery and professional site installation</span></li>
      </ul>
      <div style="margin-top:32px;display:flex;gap:14px;flex-wrap:wrap;">
        <a class="btn btn-primary" href="for-interior-designers/">Partner With The Star</a>
        <a class="btn btn-outline-light" href="for-architects/">For Architects</a>
      </div>
    </div>
    <div class="media"><img src="{PROJECTS[3]['images'][0]['lg']}" alt="Modular kitchen production quality for interior designers" loading="lazy"></div>
  </div>
</section>"""

    # G. Finish showcase
    finishes = [
        ("Acrylic", PROJECTS[0]["images"][2]["md"]),
        ("High Gloss Laminate", PROJECTS[0]["images"][0]["md"]),
        ("Glass Finish", PROJECTS[2]["images"][2]["md"]),
        ("Handleless Profiles", PROJECTS[3]["images"][1]["md"]),
        ("Sliding Wardrobes", PROJECTS[2]["images"][1]["md"]),
        ("Profile Lighting", PROJECTS[1]["images"][1]["md"]),
    ]
    body += f"""
<section class="bg-white">
  <div class="container">
    {section_head("MATERIALS &amp; FINISHES", "A finish for every design language")}
    <div class="finish-strip">
      {''.join(f'<div class="finish-tile"><img src="{img}" alt="{name} finish" loading="lazy" width="300" height="300"><span>{name}</span></div>' for name,img in finishes)}
    </div>
    <div style="margin-top:32px;"><a class="btn btn-outline" href="materials-finishes/">Explore the Materials Library {ICONS['arrow']}</a></div>
  </div>
</section>"""

    # H. Process
    steps = [
        ("01", "Share &amp; Discuss", "Tell us about your space, drawings and material preferences."),
        ("02", "Transparent Estimation", "Receive a detailed quotation with a clear material breakdown."),
        ("03", "Precision Production", "Your order is manufactured in-house with rigorous quality checks."),
        ("04", "Site Installation", "Our team delivers and installs on schedule, with minimal disruption."),
    ]
    body += f"""
<section class="bg-paper2">
  <div class="container">
    {section_head("OUR PROCESS", "From first conversation to handover")}
    <div class="process-row">
      {''.join(f'<div class="process-step"><span class="n">{n}</span><h4>{t}</h4><p>{d}</p></div>' for n,t,d in steps)}
    </div>
  </div>
</section>"""

    # I. Real project gallery (masonry)
    body += f"""
<section class="bg-white">
  <div class="container">
    {section_head("PROJECT GALLERY", "A closer look at recent work")}
    <div class="gallery-masonry" data-masonry-gallery><div class="loading-state">Loading gallery&hellip;</div></div>
  </div>
</section>"""

    # J. Testimonials
    body += f"""
<section class="bg-paper2">
  <div class="container">
    {section_head("CLIENT FEEDBACK", "What clients say")}
    <div class="testi-wrap" data-testimonials><div class="loading-state">Loading&hellip;</div></div>
  </div>
</section>"""

    # K. Social
    body += f"""
<section class="bg-white section-tight">
  <div class="container social-strip">
    <div>
      <span class="eyebrow">FOLLOW ALONG</span>
      <h3 style="margin-top:10px;">Project updates on Instagram &amp; YouTube</h3>
    </div>
    <div class="social-links">
      <a href="{INSTAGRAM}" target="_blank" rel="noopener">{ICONS['insta']}Instagram</a>
      <a href="{YOUTUBE}" target="_blank" rel="noopener">{ICONS['yt']}YouTube</a>
      <a href="{FACEBOOK}" target="_blank" rel="noopener">{ICONS['fb']}Facebook</a>
    </div>
  </div>
</section>"""

    # L. Local SEO FAQ
    body += f"""
<section class="bg-white faq-section">
  <div class="container">
    {section_head("FAQ", "Modular kitchen & interior design questions", "Answers for homeowners, architects and interior designers planning projects in Rajkot and Gujarat.")}
    <div class="faq-grid">
      <details><summary>Do you provide modular kitchen design and installation in Rajkot?</summary><p>Yes. The Star Modular Furniture provides design, manufacturing, delivery and installation for modular kitchens in Rajkot from our Tagore Road facility.</p></details>
      <details><summary>Which areas around Rajkot do you serve?</summary><p>We can coordinate projects in Rajkot and nearby areas including Gondal, Jetpur, Wankaner, Morbi, Jamnagar and other Gujarat locations depending on project scope.</p></details>
      <details><summary>Can architects and interior designers send their own drawings?</summary><p>Yes. We work from 2D or 3D drawings, dimensions, material specifications and approved design details for execution-focused collaboration.</p></details>
      <details><summary>Can you support NRI or international interior projects?</summary><p>For suitable projects, yes. Detailed drawings, material schedules, remote approvals and structured site coordination can support clients outside Rajkot and India.</p></details>
    </div>
  </div>
</section>"""
    # M. Final CTA
    body += f"""
<section class="bg-ink final-cta">
  <div class="container">
    <span class="eyebrow">START A PROJECT</span>
    <h2 style="color:#fff;margin-top:16px;">Let&rsquo;s design a space that feels unmistakably yours.</h2>
    <div class="actions">
      <a class="btn btn-primary" href="contact/">Start Your Project</a>
      <a class="btn btn-whatsapp" href="{WHATSAPP}" target="_blank" rel="noopener">{ICONS['whatsapp']}WhatsApp The Star</a>
      <a class="btn btn-outline-light" href="contact/">Visit Our Experience Center</a>
    </div>
  </div>
</section>"""

    schema = {
        "@context": "https://schema.org",
        "@type": "HomeAndConstructionBusiness",
        "name": SITE_NAME,
        "image": f"{SITE_URL}/{PROJECTS[0]['images'][0]['lg']}",
        "url": SITE_URL + "/",
        "telephone": PHONE_INTL,
        "email": EMAIL,
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Silver Chambers, Tagore Road, Opposite Atul Motors, Bhaktinagar Station Plot",
            "addressLocality": "Rajkot",
            "addressRegion": "Gujarat",
            "postalCode": "360002",
            "addressCountry": "IN"
        },
        "sameAs": [INSTAGRAM, YOUTUBE, FACEBOOK],
        "priceRange": "$$",
        "areaServed": ["Rajkot", "Gondal", "Morbi", "Jamnagar", "Jetpur", "Wankaner", "Shapar-Veraval", "Surendranagar", "Junagadh", "Bhavnagar", "Ahmedabad", "Gujarat"],
        "knowsAbout": ["Modular kitchen design", "Modular wardrobe design", "Custom furniture", "Interior design", "Interior execution", "Kitchen storage planning"]
    }

    html = page(
        "The Star Modular Furniture | Modular Kitchen, Wardrobe &amp; Interiors in Rajkot",
        "The Star Modular Furniture provides modular kitchen, wardrobe, custom furniture and interior solutions in Rajkot, Gujarat, with project support across nearby cities and selected locations across India.",
        "", "", body, root_depth=0, og_image=PROJECTS[0]["images"][0]["md"], schema=schema
    )
    write("index.html", html)
