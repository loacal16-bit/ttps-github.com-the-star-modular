from generate import *

def build_about():
    root = rel(1)
    body = hero(
        "OUR STORY", "Built on trust, driven by functionality.",
        "The Star Modular Furniture designs, manufactures and installs modular kitchens, wardrobes and custom furniture from our Rajkot facility and experience center.",
        f'<a class="btn btn-primary" href="{root}contact/">Get a Consultation</a><a class="btn btn-outline-light" href="{root}brochure/The-Star-Modular-Furniture-Brochure.pdf" target="_blank">Download Brochure</a>',
        PROJECTS[2]["images"][0]["lg"], root, tall=False,
        breadcrumbs=[("Home","."),("About", None)]
    )

    body += f"""
<section class="bg-white">
  <div class="container intro-grid">
    <div>
      <span class="eyebrow">WHO WE ARE</span>
      <h2>Smart spaces, smart solutions.</h2>
      <p class="lede" style="margin-top:18px;">The Star Modular Furniture is a Rajkot-based modular furniture manufacturer specialising in modular kitchens, wardrobes and custom interior furniture. Our showroom and experience center on Tagore Road lets clients see material finishes, hardware and colours in person before a single panel is cut.</p>
      <p class="lede" style="margin-top:16px;">We work directly with homeowners, and alongside interior designers and architects who share their own drawings and specifications — production, delivery and installation are ours to handle, so the design stays entirely in your hands.</p>
      <div style="margin-top:32px;"><a class="btn btn-outline" href="{root}for-interior-designers/">How We Work With Designers {ICONS['arrow']}</a></div>
    </div>
    <div>
      <img src="{root}{PROJECTS[1]['images'][0]['md']}" alt="Modular kitchen production by The Star Modular Furniture" loading="lazy" width="900" height="675" style="aspect-ratio:4/3;object-fit:cover;">
    </div>
  </div>
</section>"""

    features = [
        ("Precision Manufacturing", "Panels cut, edge-banded and drilled against the approved drawing, not approximated on site."),
        ("Designer-Centric Approach", "Your dimensions, material specification and design language, followed strictly."),
        ("Transparent Estimation", "A detailed, itemised quotation with a clear material-by-material breakdown."),
        ("Professional Installation", "Our own site team, not a subcontractor, handles delivery and installation."),
        ("Quality Materials", "Acrylic, PU paint, glass, high-gloss laminate and handleless profile hardware."),
        ("Timely Execution", "Committed timelines tracked from estimation through to handover."),
    ]
    body += f"""
<section class="bg-paper2">
  <div class="container">
    {section_head("WHY CLIENTS WORK WITH US", "What we hold ourselves to")}
    <div class="feature-list">
      {''.join(f'<div class="feature-item"><h4>{t}</h4><p>{d}</p></div>' for t,d in features)}
    </div>
  </div>
</section>"""

    body += f"""
<section class="bg-navy" style="padding:0;">
  <div class="split-panel reverse">
    <div class="copy">
      <span class="eyebrow" style="color:#8fa0ff;">EXPERIENCE CENTER</span>
      <h2 style="color:#fff;">Visit our Tagore Road showroom.</h2>
      <p class="lede">See modular displays and material samples in person — acrylic, PU paint, glass and laminate finishes, handleless profiles and wardrobe hardware, all on show at our Rajkot experience center.</p>
      <ul class="mini-steps">
        <li><span class="n">{ICONS['pin']}</span><span>{ADDRESS_ONE_LINE}</span></li>
        <li><span class="n">{ICONS['phone']}</span><span>{PHONE_DISPLAY} / {PHONE2_DISPLAY}</span></li>
        <li><span class="n">{ICONS['mail']}</span><span>{EMAIL}</span></li>
      </ul>
      <div style="margin-top:32px;"><a class="btn btn-primary" href="{root}contact/">Book a Visit</a></div>
    </div>
    <div class="media"><img src="{root}{PROJECTS[0]['images'][2]['lg']}" alt="The Star Modular Furniture experience center, Rajkot" loading="lazy"></div>
  </div>
</section>"""

    body += f"""
<section class="bg-white">
  <div class="container">
    {section_head("SERVING", "Rajkot, and beyond for design consultation")}
    <p class="lede">Manufacturing, delivery and installation are based from Rajkot, Gujarat. For interior designers, architects, developers and NRI homeowners outside Rajkot, we also offer remote design consultation and project coordination — see <a href="{root}for-interior-designers/" style="color:var(--blue);text-decoration:underline;">For Interior Designers</a> for how this works.</p>
  </div>
</section>"""

    html = page(
        "About The Star Modular Furniture | Rajkot Modular Kitchen &amp; Wardrobe Manufacturer",
        "The Star Modular Furniture is a Rajkot-based modular kitchen, wardrobe and custom furniture manufacturer, with an experience center on Tagore Road.",
        "about/", "about/", body, root_depth=1, og_image=PROJECTS[2]["images"][0]["md"]
    )
    write("about/index.html", html)


SERVICE_DEFS = {
    "modular-kitchens": {
        "eyebrow": "MODULAR KITCHENS",
        "h1": "Modular kitchens, built to your layout.",
        "lede": "L-shape, U-shape, parallel and island-style kitchens in acrylic, PU paint, glass and high-gloss laminate finishes — manufactured to your exact dimensions.",
        "hero_img": PROJECTS[0]["images"][0]["lg"],
        "intro": "Every kitchen starts with your layout and the way you actually cook — storage for daily use, a dedicated larder, worktop space near the hob, and hardware that stays smooth for years. We manufacture each carcass and shutter to the approved drawing, then install and test every drawer, hinge and profile on site.",
        "highlights": [
            ("Layouts", "L-shape, U-shape, parallel and island / breakfast-counter configurations."),
            ("Shutter Finishes", "Acrylic, PU paint, glass finish and high-gloss laminate."),
            ("Countertops", "Stone-finish and quartz-finish countertops and matching backsplashes."),
            ("Storage", "Tall larder units, pull-out baskets, corner units and drawer systems."),
            ("Lighting", "Under-cabinet and profile LED lighting, wired discreetly into the carcass."),
            ("Hardware", "Soft-close hinges and channels, and handleless push-to-open profiles."),
        ],
        "gallery_slugs": ["dual-tone-island-kitchen","verde-marble-kitchen","ivory-backlit-kitchen"],
        "related_category": "Modular Kitchen",
        "seo_title": "Modular Kitchens Rajkot | Custom Kitchen Design &amp; Installation | The Star",
        "seo_desc": "Custom modular kitchens in Rajkot — L-shape, U-shape and island layouts in acrylic, PU, glass and laminate finishes. Designed, manufactured and installed by The Star Modular Furniture.",
    },
    "modular-wardrobes": {
        "eyebrow": "MODULAR WARDROBES",
        "h1": "Wardrobes planned around how you dress.",
        "lede": "Sliding, hinged and walk-in wardrobe systems with glass-front shutters, pull-out accessory racks and profile lighting.",
        "hero_img": PROJECTS[2]["images"][0]["lg"],
        "intro": "A wardrobe is used every day, so we plan the internal layout first — hanging bays, shelving, drawer zones and accessory storage — before choosing the shutter finish. Walk-in configurations, sliding-door and hinged-door wardrobes are all built on the same standard of hardware and finish.",
        "highlights": [
            ("Configurations", "Sliding-door, hinged-door and open walk-in wardrobe layouts."),
            ("Interior Fit-Outs", "Pull-out trouser and accessory racks, shoe racks and jewellery drawers."),
            ("Shutter Finishes", "Glass-front, laminate and high-gloss shutter options."),
            ("Lighting", "Profile LED lighting fitted inside wardrobe columns and display units."),
            ("Hardware", "Soft-close hinges and telescopic channels on every drawer and rack."),
        ],
        "gallery_slugs": ["walk-in-wardrobe-system"],
        "related_category": "Modular Wardrobe",
        "seo_title": "Modular Wardrobes Rajkot | Sliding &amp; Walk-In Wardrobe Design | The Star",
        "seo_desc": "Custom modular wardrobes in Rajkot — sliding, hinged and walk-in systems with glass-front shutters and profile lighting, by The Star Modular Furniture.",
    },
    "modular-furniture": {
        "eyebrow": "MODULAR FURNITURE",
        "h1": "Custom furniture, matched to your interior.",
        "lede": "TV units, crockery units, study units and bespoke furniture pieces built to your dimensions and finish palette.",
        "hero_img": PROJECTS[1]["images"][0]["lg"],
        "intro": "Beyond kitchens and wardrobes, we manufacture custom furniture pieces designed to sit within a larger interior scheme — matched in material, finish and hardware to the rest of the home, and built with the same factory-grade precision.",
        "highlights": [
            ("TV &amp; Media Units", "Wall-mounted and floor-standing units with cable management."),
            ("Crockery &amp; Display Units", "Glass-front and open-shelf display furniture for dining spaces."),
            ("Study &amp; Office Furniture", "Custom desks, storage units and shelving for home offices."),
            ("Bespoke Pieces", "One-off furniture built to a designer's drawing and material spec."),
        ],
        "gallery_slugs": ["dual-tone-island-kitchen","verde-marble-kitchen"],
        "related_category": "Modular Furniture",
        "seo_title": "Custom Modular Furniture Rajkot | The Star Modular Furniture",
        "seo_desc": "Custom modular furniture in Rajkot — TV units, crockery units and bespoke furniture pieces built to your dimensions, by The Star Modular Furniture.",
    },
    "interior-solutions": {
        "eyebrow": "INTERIOR SOLUTIONS",
        "h1": "Coordinated execution for full interiors.",
        "lede": "Execution support for full-home and commercial interior projects — from kitchen and wardrobes through to custom furniture, coordinated as one project.",
        "hero_img": PROJECTS[3]["images"][0]["lg"],
        "intro": "For clients fitting out a full home or a commercial space, we coordinate modular kitchen, wardrobe and custom furniture production as a single project — one point of contact, one production schedule and one installation team.",
        "highlights": [
            ("Residential Interiors", "Full-home modular furniture coordinated across every room."),
            ("Commercial Projects", "Offices, showrooms and retail interiors with modular fit-outs."),
            ("Single Point of Contact", "One estimation, one production schedule, one installation team."),
            ("Designer &amp; Architect Coordination", "Execution against drawings supplied by your design team."),
        ],
        "gallery_slugs": ["verde-marble-kitchen","walk-in-wardrobe-system"],
        "related_category": None,
        "seo_title": "Interior Solutions Rajkot | Residential &amp; Commercial Furniture Execution | The Star",
        "seo_desc": "Coordinated modular furniture execution for residential and commercial interiors in Rajkot, from kitchens and wardrobes to custom furniture.",
    },
}

def build_service_pages():
    for slug, d in SERVICE_DEFS.items():
        root = rel(1)
        body = hero(d["eyebrow"], d["h1"], d["lede"],
            f'<a class="btn btn-primary" href="{root}contact/">Request a Quote</a><a class="btn btn-outline-light" href="{root}projects/">View Projects</a>',
            d["hero_img"], root, tall=False, breadcrumbs=[("Home","."),(d["eyebrow"].title(), None)])

        body += f"""
<section class="bg-white">
  <div class="container">
    <div class="intro-grid">
      <div><span class="eyebrow">OVERVIEW</span><h2>Designed around how you live.</h2><p class="lede" style="margin-top:18px;">{d['intro']}</p></div>
      <div><img src="{root}{PROJECTS[0]['images'][1]['md']}" alt="{d['h1']}" loading="lazy" width="900" height="675" style="aspect-ratio:4/3;object-fit:cover;"></div>
    </div>
  </div>
</section>"""

        body += f"""
<section class="bg-paper2">
  <div class="container">
    {section_head("WHAT'S INCLUDED", "Specification highlights")}
    <div class="feature-list">
      {''.join(f'<div class="feature-item"><h4>{t}</h4><p>{desc}</p></div>' for t,desc in d['highlights'])}
    </div>
  </div>
</section>"""

        gimgs = []
        for gslug in d["gallery_slugs"]:
            proj = next(p for p in PROJECTS if p["slug"] == gslug)
            gimgs.append((proj["images"][0]["md"], proj["images"][0]["lg"], proj["title"]))
        body += f"""
<section class="bg-white">
  <div class="container">
    {section_head("RECENT WORK", "See it built")}
    <div class="gallery-masonry">
      {''.join(f'<div class="g-item" data-lightbox data-full="{root}{lg}"><img src="{root}{md}" alt="{title}" loading="lazy" width="900" height="650"></div>' for md,lg,title in gimgs)}
    </div>
    <div style="margin-top:32px;"><a class="btn btn-outline" href="{root}projects/">View All Projects {ICONS['arrow']}</a></div>
  </div>
</section>"""

        body += f"""
<section class="bg-ink final-cta">
  <div class="container">
    <span class="eyebrow">GET STARTED</span>
    <h2 style="color:#fff;margin-top:16px;">Discuss your {d['eyebrow'].lower()} project.</h2>
    <div class="actions">
      <a class="btn btn-primary" href="{root}contact/">Request a Quote</a>
      <a class="btn btn-whatsapp" href="{WHATSAPP}" target="_blank" rel="noopener">{ICONS['whatsapp']}WhatsApp Us</a>
    </div>
  </div>
</section>"""

        schema = {
            "@context": "https://schema.org",
            "@type": "Service",
            "serviceType": d["h1"],
            "provider": {"@type": "LocalBusiness", "name": SITE_NAME, "telephone": PHONE_INTL},
            "areaServed": "Rajkot, Gujarat",
            "description": d["seo_desc"],
        }
        html = page(d["seo_title"], d["seo_desc"], f"{slug}/", f"{slug}/", body, root_depth=1, og_image=d["hero_img"].replace("-lg.webp","-md.webp"), schema=schema)
        write(f"{slug}/index.html", html)
