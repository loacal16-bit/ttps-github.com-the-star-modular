import os, json, shutil
from generate import ROOT_OUT, SITE_URL, PROJECTS, write
from pages_home import build_home
from pages_services import build_about, build_service_pages
from pages_projects import (build_projects_listing, build_project_details,
                             build_for_designers, build_for_architects,
                             build_materials, build_process)
from pages_blog import build_blog_listing, build_blog_posts, POSTS
from pages_legal import (build_contact, build_legal_pages, build_sitemap_page,
                          build_location_pages, build_404)

def main():
    build_home()
    build_about()
    build_service_pages()
    build_projects_listing()
    build_project_details()
    build_for_designers()
    build_for_architects()
    build_materials()
    build_process()
    build_blog_listing()
    build_blog_posts()
    build_contact()
    build_legal_pages()
    build_location_pages()
    build_sitemap_page()
    build_404()

    # ---- robots.txt ----
    robots = f"""User-agent: *
Allow: /
Sitemap: {SITE_URL}/sitemap.xml
"""
    with open(os.path.join(ROOT_OUT, "robots.txt"), "w") as f:
        f.write(robots)

    # ---- sitemap.xml ----
    static_paths = [
        "", "about/", "modular-kitchens/", "modular-wardrobes/", "modular-furniture/",
        "interior-solutions/", "projects/", "for-interior-designers/", "for-architects/",
        "materials-finishes/", "our-process/", "blog/", "contact/", "privacy-policy/",
        "terms-conditions/", "sitemap/", "modular-kitchen-rajkot/", "modular-wardrobe-rajkot/",
        "modular-furniture-rajkot/",
    ]
    paths = list(static_paths)
    paths += [f"projects/{p['slug']}/" for p in PROJECTS]
    paths += [f"blog/{b['slug']}/" for b in POSTS]

    urlset = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for p in paths:
        urlset.append(f"  <url><loc>{SITE_URL}/{p}</loc></url>")
    urlset.append("</urlset>")
    with open(os.path.join(ROOT_OUT, "sitemap.xml"), "w") as f:
        f.write("\n".join(urlset))

    print(f"\nGenerated {len(paths)} pages + robots.txt + sitemap.xml")

if __name__ == "__main__":
    main()
