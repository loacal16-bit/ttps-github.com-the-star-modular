/* THE STAR MODULAR FURNITURE — site behaviour
   Vanilla JS, no build step. Renders CMS-style content from /data/*.json
   so non-developers can update Projects, Materials and Blog by editing
   flat JSON files (see /admin-notes/README for upgrading to a real DB+admin). */
(function () {
  "use strict";

  var ROOT = document.documentElement.getAttribute("data-root") || "";

  /* ---------------- Mobile nav ---------------- */
  var navToggle = document.querySelector(".nav-toggle");
  var mainNav = document.querySelector(".main-nav");
  if (navToggle && mainNav) {
    navToggle.addEventListener("click", function () {
      var open = mainNav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", open ? "true" : "false");
      document.body.style.overflow = open ? "hidden" : "";
    });
    mainNav.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        mainNav.classList.remove("open");
        document.body.style.overflow = "";
      });
    });
  }

  /* ---------------- Architecture & Interiors mega menu ---------------- */
  var dropdown = document.querySelector(".nav-dropdown");
  var dropdownToggle = document.querySelector(".nav-dropdown-toggle");
  if (dropdown && dropdownToggle) {
    dropdownToggle.addEventListener("click", function (event) {
      event.stopPropagation();
      var open = dropdown.classList.toggle("open");
      dropdownToggle.setAttribute("aria-expanded", open ? "true" : "false");
      var mega = dropdown.querySelector(".nav-mega");
      if (mega) mega.setAttribute("aria-hidden", open ? "false" : "true");
    });

    document.addEventListener("click", function (event) {
      if (!dropdown.contains(event.target)) {
        dropdown.classList.remove("open");
        dropdownToggle.setAttribute("aria-expanded", "false");
        var mega = dropdown.querySelector(".nav-mega");
        if (mega) mega.setAttribute("aria-hidden", "true");
      }
    });

    dropdown.querySelectorAll(".nav-mega a").forEach(function (a) {
      a.addEventListener("click", function () {
        dropdown.classList.remove("open");
        dropdownToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* ---------------- Header shadow on scroll ---------------- */
  var header = document.querySelector(".site-header");
  if (header) {
    var lastY = 0;
    window.addEventListener(
      "scroll",
      function () {
        header.style.boxShadow = window.scrollY > 4 ? "0 8px 28px rgba(11,60,193,.08)" : "0 8px 30px rgba(11,60,193,.055)";
        lastY = window.scrollY;
      },
      { passive: true }
    );
  }

  /* ---------------- Lightbox ---------------- */
  var lb = document.createElement("div");
  lb.className = "lightbox";
  lb.innerHTML =
    '<button class="lightbox-close" aria-label="Close">&times;</button>' +
    '<button class="lightbox-nav lightbox-prev" aria-label="Previous">&#8249;</button>' +
    '<img alt="">' +
    '<button class="lightbox-nav lightbox-next" aria-label="Next">&#8250;</button>';
  document.body.appendChild(lb);
  var lbImg = lb.querySelector("img");
  var lbGroup = [];
  var lbIndex = 0;

  function openLightbox(group, index) {
    lbGroup = group;
    lbIndex = index;
    lbImg.src = lbGroup[lbIndex];
    lb.classList.add("open");
    document.body.style.overflow = "hidden";
  }
  function closeLightbox() {
    lb.classList.remove("open");
    document.body.style.overflow = "";
  }
  function stepLightbox(delta) {
    lbIndex = (lbIndex + delta + lbGroup.length) % lbGroup.length;
    lbImg.src = lbGroup[lbIndex];
  }
  lb.querySelector(".lightbox-close").addEventListener("click", closeLightbox);
  lb.addEventListener("click", function (e) {
    if (e.target === lb) closeLightbox();
  });
  lb.querySelector(".lightbox-prev").addEventListener("click", function () {
    stepLightbox(-1);
  });
  lb.querySelector(".lightbox-next").addEventListener("click", function () {
    stepLightbox(1);
  });
  document.addEventListener("keydown", function (e) {
    if (!lb.classList.contains("open")) return;
    if (e.key === "Escape") closeLightbox();
    if (e.key === "ArrowLeft") stepLightbox(-1);
    if (e.key === "ArrowRight") stepLightbox(1);
  });

  function wireLightboxGroup(selector) {
    var nodes = Array.prototype.slice.call(document.querySelectorAll(selector));
    if (!nodes.length) return;
    var group = nodes.map(function (n) {
      return n.getAttribute("data-full") || n.querySelector("img").src;
    });
    nodes.forEach(function (n, i) {
      n.addEventListener("click", function (e) {
        e.preventDefault();
        openLightbox(group, i);
      });
    });
  }
  wireLightboxGroup("[data-lightbox]");

  /* ---------------- Fetch helper ---------------- */
  function getJSON(path) {
    return fetch(ROOT + path).then(function (r) {
      if (!r.ok) throw new Error("Failed to load " + path);
      return r.json();
    });
  }

  /* ---------------- Projects: grid + filters ---------------- */
  var projectGrid = document.querySelector("[data-project-grid]");
  if (projectGrid) {
    getJSON("data/projects.json")
      .then(function (projects) {
        renderProjects(projects);
        wireFilters(projects);
      })
      .catch(function () {
        projectGrid.innerHTML = '<p class="empty-state">Projects will appear here shortly.</p>';
      });
  }

  function projectCard(p) {
    var img = p.images && p.images[0] ? p.images[0].md : "";
    return (
      '<a class="project-card" href="' + ROOT + "projects/" + p.slug + '/">' +
      '<div class="thumb"><img src="' + ROOT + img + '" alt="' + esc(p.title) + " — " + esc(p.category) + '" loading="lazy" decoding="async" width="900" height="675"></div>' +
      '<div class="body"><span class="cat">' + esc(p.category) + "</span><h3>" + esc(p.title) + '</h3><span class="loc">' + esc(p.location) + "</span></div>" +
      "</a>"
    );
  }

  function renderProjects(list) {
    if (!list.length) {
      projectGrid.innerHTML = '<p class="empty-state">No projects published yet. Check back soon.</p>';
      return;
    }
    projectGrid.innerHTML = list.map(projectCard).join("");
  }

  function wireFilters(all) {
    var chips = document.querySelectorAll("[data-filter-chip]");
    if (!chips.length) return;
    chips.forEach(function (chip) {
      chip.addEventListener("click", function () {
        chips.forEach(function (c) {
          c.classList.remove("active");
        });
        chip.classList.add("active");
        var cat = chip.getAttribute("data-filter-chip");
        var filtered = cat === "all" ? all : all.filter(function (p) {
          return p.category === cat;
        });
        renderProjects(filtered);
      });
    });
  }

  /* ---------------- Featured projects (home) ---------------- */
  var featuredGrid = document.querySelector("[data-featured-projects]");
  if (featuredGrid) {
    getJSON("data/projects.json")
      .then(function (projects) {
        var count = parseInt(featuredGrid.getAttribute("data-count") || "3", 10);
        featuredGrid.innerHTML = projects.slice(0, count).map(projectCard).join("");
      })
      .catch(function () {});
  }

  /* ---------------- Home masonry gallery ---------------- */
  var masonry = document.querySelector("[data-masonry-gallery]");
  if (masonry) {
    getJSON("data/projects.json").then(function (projects) {
      var shots = [];
      projects.forEach(function (p) {
        (p.images || []).forEach(function (img) {
          shots.push({ md: img.md, lg: img.lg, alt: p.title });
        });
      });
      // interesting spread, cap at 9
      shots = shots.slice(0, 9);
      masonry.innerHTML = shots
        .map(function (s) {
          return (
            '<div class="g-item" data-lightbox data-full="' + ROOT + s.lg + '"><img src="' + ROOT + s.md + '" alt="' + esc(s.alt) + '" loading="lazy" decoding="async" width="900" height="650"></div>'
          );
        })
        .join("");
      wireLightboxGroup("[data-masonry-gallery] [data-lightbox]");
    });
  }

  /* ---------------- Project detail gallery ---------------- */
  var pdGallery = document.querySelector("[data-pd-gallery]");
  if (pdGallery) {
    var slug = pdGallery.getAttribute("data-pd-gallery");
    getJSON("data/projects.json").then(function (projects) {
      var p = projects.find(function (x) {
        return x.slug === slug;
      });
      if (!p) return;
      pdGallery.innerHTML = p.images
        .map(function (img, i) {
          var wide = i === 0 ? " wide" : "";
          return (
            '<div class="' + wide.trim() + '" data-lightbox data-full="' + ROOT + img.lg + '"><img class="' + wide.trim() + '" src="' + ROOT + img.md + '" alt="' + esc(p.title) + " photo " + (i + 1) + '" loading="' + (i === 0 ? "eager" : "lazy") + '" width="900" height="650"></div>'
          );
        })
        .join("");
      wireLightboxGroup("[data-pd-gallery] [data-lightbox]");

      var related = document.querySelector("[data-related-projects]");
      if (related) {
        var others = projects.filter(function (x) {
          return x.slug !== slug && x.category === p.category;
        });
        if (!others.length) others = projects.filter(function (x) { return x.slug !== slug; });
        related.innerHTML = others.slice(0, 3).map(projectCard).join("");
      }
    });
  }

  /* ---------------- Materials ---------------- */
  var materialGrid = document.querySelector("[data-material-grid]");
  if (materialGrid) {
    getJSON("data/materials.json")
      .then(function (materials) {
        if (!materials.length) {
          materialGrid.innerHTML = '<p class="empty-state">The materials library is being updated. Please contact us for current finish samples.</p>';
          return;
        }
        materialGrid.innerHTML = materials
          .map(function (m) {
            return (
              '<div class="material-card"><div class="swatch"><img src="' + ROOT + m.image + '" alt="' + esc(m.name) + '" loading="lazy" width="400" height="400"></div>' +
              '<div class="info"><span class="cat">' + esc(m.category) + "</span><h4>" + esc(m.name) + "</h4><p>" + esc(m.description) + "</p></div></div>"
            );
          })
          .join("");
      })
      .catch(function () {
        materialGrid.innerHTML = '<p class="empty-state">The materials library is being updated. Please contact us for current finish samples.</p>';
      });
  }

  /* ---------------- Testimonials (CMS-driven, no fake data) ---------------- */
  var testiWrap = document.querySelector("[data-testimonials]");
  if (testiWrap) {
    getJSON("data/testimonials.json")
      .then(function (items) {
        if (!items.length) {
          testiWrap.innerHTML =
            '<div class="testi-empty">Client stories are added here as projects are completed and reviewed. Ask us for recent client references at your consultation.</div>';
          return;
        }
        testiWrap.innerHTML = items
          .slice(0, 6)
          .map(function (t) {
            return '<div class="testi-card"><p>&ldquo;' + esc(t.quote) + '&rdquo;</p><div class="who">' + esc(t.name) + (t.location ? ", " + esc(t.location) : "") + "</div></div>";
          })
          .join("");
      })
      .catch(function () {
        testiWrap.innerHTML = '<div class="testi-empty">Client stories are added here as projects are completed and reviewed.</div>';
      });
  }

  /* ---------------- Blog ---------------- */
  var blogGrid = document.querySelector("[data-blog-grid]");
  if (blogGrid) {
    getJSON("data/blog.json")
      .then(function (posts) {
        if (!posts.length) {
          blogGrid.innerHTML = '<p class="empty-state">New articles are on the way.</p>';
          return;
        }
        blogGrid.innerHTML = posts
          .map(function (b) {
            return (
              '<a class="blog-card" href="' + ROOT + "blog/" + b.slug + '/">' +
              '<div class="thumb"><img src="' + ROOT + b.image + '" alt="' + esc(b.title) + '" loading="lazy" decoding="async" width="640" height="400"></div>' +
              '<span class="cat">' + esc(b.category) + "</span><h3>" + esc(b.title) + "</h3><p>" + esc(b.excerpt) + "</p></a>"
            );
          })
          .join("");
      })
      .catch(function () {
        blogGrid.innerHTML = '<p class="empty-state">New articles are on the way.</p>';
      });
  }

  /* ---------------- Contact / consultation forms ----------------
     No backend is wired up in this static build. Submissions are
     handed to WhatsApp (primary) with a mailto fallback, so leads
     reach the business immediately without a server. Swap this for
     a real POST to your CRM/database once the backend is live —
     see /README.md. */
  var WHATSAPP_NUMBER = "919016488859";

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  document.querySelectorAll("[data-lead-form]").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var data = new FormData(form);
      var name = data.get("name") || "";
      var phone = data.get("phone") || "";
      var email = data.get("email") || "";
      var city = data.get("city") || "";
      var type = data.get("project_type") || "";
      var budget = data.get("budget") || "";
      var message = data.get("message") || "";

      var lines = [
        "New enquiry from thestarmodular.in",
        "Name: " + name,
        "Phone: " + phone,
        email ? "Email: " + email : "",
        city ? "City: " + city : "",
        type ? "Project type: " + type : "",
        budget ? "Budget range: " + budget : "",
        message ? "Message: " + message : "",
      ].filter(Boolean);

      var text = encodeURIComponent(lines.join("\n"));
      var status = form.querySelector("[data-form-status]");
      if (status) {
        status.hidden = false;
        status.textContent = "Opening WhatsApp to send your enquiry…";
      }
      window.open("https://wa.me/" + WHATSAPP_NUMBER + "?text=" + text, "_blank");
      form.reset();
    });
  });
})();
