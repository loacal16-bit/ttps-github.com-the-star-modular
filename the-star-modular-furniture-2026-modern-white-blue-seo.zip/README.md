# The Star Modular Furniture — Website

A premium, SEO-optimised, production-ready website for The Star Modular
Furniture (Rajkot, Gujarat), built from your real project photography,
logo and brochure.

This package is a **static site** — no server, database or build step is
required to run it. Open `index.html` in a browser, or upload the whole
`the-star-website` folder to any static host (see **Deployment** below).

---

## 1. What's included

- **26 pages**: Home, About, 4 service pages (Modular Kitchens, Modular
  Wardrobes, Modular Furniture, Interior Solutions), Projects listing + 4
  project detail pages, For Interior Designers, For Architects, Materials
  & Finishes, Our Process, Blog listing + 3 articles, Contact, Privacy
  Policy, Terms & Conditions, Sitemap, 3 local-SEO location pages
  (`/modular-kitchen-rajkot/`, `/modular-wardrobe-rajkot/`,
  `/modular-furniture-rajkot/`), and a 404 page.
- **Real photography only** — every image is from your uploaded ZIP,
  optimised into responsive WebP sizes (`-sm`, `-md`, `-lg`). No stock
  photography anywhere on the site.
- **Design system** matched to your logo's cobalt-blue brand colour, with
  Fraunces (headings) + Manrope (body) typography, a restrained
  neutral/paper palette, and no stock-template UI.
- **Technical SEO**: unique title/meta description per page, canonical
  URLs, Open Graph + Twitter Card tags, JSON-LD schema (LocalBusiness,
  Service, Article, BreadcrumbList), semantic HTML, `robots.txt` and
  `sitemap.xml`.
- **Performance**: responsive WebP images with `srcset`-ready sizes, lazy
  loading below the fold, no build tooling or heavy JS framework, a
  single ~30 KB CSS file and a single ~10 KB JS file.
- **Accessibility**: semantic landmarks, skip-to-content link, visible
  focus states, keyboard-operable lightbox and nav, alt text on every
  image, `prefers-reduced-motion` support.
- **Lead capture**: the contact form and every "Request a Quote" style
  CTA opens a pre-filled WhatsApp message to `+91 90164 88859` (with an
  email fallback), so enquiries reach you immediately with **no backend
  required**. See section 4 for upgrading this to a real database.
- **Downloadable brochure** at `/brochure/The-Star-Modular-Furniture-Brochure.pdf`,
  linked from the About page and footer.

## 2. Folder structure

```
the-star-website/
├── index.html                     Home
├── about/index.html
├── modular-kitchens/index.html
├── modular-wardrobes/index.html
├── modular-furniture/index.html
├── interior-solutions/index.html
├── projects/
│   ├── index.html                 Projects listing (filterable grid)
│   ├── verde-marble-kitchen/index.html
│   ├── dual-tone-island-kitchen/index.html
│   ├── ivory-backlit-kitchen/index.html
│   └── walk-in-wardrobe-system/index.html
├── for-interior-designers/index.html
├── for-architects/index.html
├── materials-finishes/index.html
├── our-process/index.html
├── blog/
│   ├── index.html
│   ├── acrylic-vs-laminate-kitchen/index.html
│   ├── modular-wardrobe-planning-guide/index.html
│   └── modular-kitchen-layout-mistakes/index.html
├── contact/index.html
├── privacy-policy/index.html
├── terms-conditions/index.html
├── sitemap/index.html             human-readable sitemap
├── modular-kitchen-rajkot/index.html      \
├── modular-wardrobe-rajkot/index.html      > local-SEO landing pages
├── modular-furniture-rajkot/index.html    /
├── 404.html
├── robots.txt
├── sitemap.xml                    machine sitemap for search engines
├── favicon.ico
├── brochure/
│   └── The-Star-Modular-Furniture-Brochure.pdf
├── data/                          ← the "flat-file CMS" (see section 3)
│   ├── projects.json
│   ├── materials.json
│   ├── blog.json
│   └── testimonials.json
└── assets/
    ├── css/style.css
    ├── js/main.js
    └── img/
        ├── brand/                 logo & favicon variants
        ├── og/                    default social-share image
        └── projects/<slug>/       optimised photos, 3 sizes each
```

## 3. Updating content (no developer required)

Projects, materials/finishes and blog posts are **not hardcoded** — they're
read at runtime from the JSON files in `/data/` by `assets/js/main.js`.
To add, edit or remove one, open the relevant `.json` file in any text
editor and follow the existing pattern. For example, to add a project,
copy an existing object in `data/projects.json`, give it a new `slug`,
and add your photos under `assets/img/projects/<slug>/` at three sizes
(`-sm`, `-md`, `-lg`) — or simply reuse one size for all three if you
don't want to resize images yourself.

**Testimonials**: `data/testimonials.json` ships empty, on purpose — no
placeholder or fabricated reviews have been added. Add real client
testimonials there as they come in; the homepage will start showing them
automatically instead of the current "ask us for references" message.

This works well for a small, hand-maintained catalogue. It is **not** a
substitute for a real admin panel with logins, image upload, and a lead
inbox — see section 4 for that.

## 4. About the CMS, admin panel & lead database the brief asked for

The original brief asked for a full database-backed admin system: secure
login, project/blog/materials CRUD with image upload, a leads inbox with
status tracking, analytics integration, and so on. **That requires a
real server and database that stays running continuously** — it isn't
something that can be delivered as a static ZIP file, because there's
nowhere for it to run once you unzip it.

What's delivered instead is everything that *can* live in a static
package: a complete, fast, SEO-correct frontend, plus a JSON-based
content layer (section 3) that avoids hardcoding your content into HTML.
Contact form submissions currently go straight to WhatsApp/email rather
than into a database.

If and when you want the full admin system, here's a concrete,
proven path:

**Recommended stack**
- **Frontend**: keep this design; rebuild the templates in Next.js
  (React) so pages can be served dynamically from a database instead of
  static JSON.
- **Backend/API**: Node.js with Express, or Next.js API routes / server
  actions.
- **Database**: PostgreSQL (e.g. via Supabase, Neon, or a managed
  droplet) using an ORM like Prisma.
- **Auth**: NextAuth.js or Lucia, with a single admin role to start.
- **Image storage**: S3-compatible storage (AWS S3, Cloudflare R2, or
  Supabase Storage) with on-upload resizing (e.g. `sharp`).
- **Hosting**: Vercel or Railway for the app, with the database hosted
  alongside it.

**Suggested database schema** (tables → key columns):
- `admins` — id, email, password_hash, role
- `projects` — id, slug, title, category_id, location, year,
  client_type, description, is_published, seo_title, seo_description,
  created_at
- `project_images` — id, project_id, url, alt_text, sort_order,
  is_featured
- `categories` — id, name, type (project/blog)
- `materials` — id, name, category, image_url, description, status
- `locations` — id, slug, title, body, is_published
- `blog_posts` — id, slug, title, category_id, body, featured_image,
  seo_title, seo_description, focus_keyword, author, published_at,
  is_published
- `testimonials` — id, name, location, quote, is_published
- `leads` — id, name, phone, email, city, project_type, budget_range,
  message, attachment_url, status (new/contacted/qualified/closed),
  created_at
- `site_settings` — key, value (for phone numbers, addresses, social
  links, so they're editable without a code change)

**Migration approach**: the JSON files in `/data/` map almost directly
onto the `projects`, `materials`, `blog_posts` and `testimonials` tables
above — a developer can write a one-off script to import them directly,
so no content entered between now and then would be lost.

## 5. SEO implementation summary

- Unique `<title>` and meta description on every page, written for
  the specific page's intent (not templated boilerplate).
- Canonical URL tag on every page.
- Open Graph + Twitter Card tags with a real project photo per page.
- JSON-LD structured data: `LocalBusiness`/`HomeAndConstructionBusiness`
  on the homepage and location pages, `Service` on service pages,
  `Article` on blog posts, `BreadcrumbList` on project detail pages,
  `CollectionPage` on the projects listing.
- Clean, descriptive URLs (`/modular-kitchens/`, `/projects/<slug>/`)
  with no query strings or IDs.
- Semantic HTML: one `<h1>` per page, logical `<h2>`/`<h3>` hierarchy,
  `<nav>`/`<main>`/`<footer>` landmarks.
- Breadcrumb navigation (visual + schema) on every interior page.
- Internal linking: services link to related projects, projects link
  back to services and to related projects, blog posts link to contact,
  footer sitemap links every page from every page.
- `robots.txt` and `sitemap.xml` generated and included.
- **Before launch**: update `SITE_URL` in `generate.py` (currently a
  placeholder, `https://www.thestarmodular.in`) to your real domain and
  regenerate, so canonical/OG URLs and the sitemap are correct. Also
  submit the sitemap to Google Search Console once live.

## 6. Performance summary

- Every photo is served as WebP in three sizes; pages reference the
  size appropriate to where it's used (thumbnails use `-md`, lightbox
  and hero images use `-lg`).
- Images below the fold use `loading="lazy"`; the hero image on each
  page uses `fetchpriority="high"` since it's the largest visible
  element.
- No JavaScript framework, bundler or build step — one ~30 KB CSS file
  and one ~10 KB JS file, both cacheable, loaded once across the whole
  site.
- Fonts are loaded from Google Fonts with `preconnect` hints and
  `display=swap` so text is never invisible while fonts load.
- No autoplaying video, no heavy embedded social widgets (Instagram/
  YouTube/Facebook are plain links, per the brief, to avoid the
  performance cost of embedded widgets).

## 7. Deployment instructions

Because this is a static site, you have several straightforward options:

**Option A — Netlify / Vercel / Cloudflare Pages (recommended, free tier
available)**
1. Create an account and a new site.
2. Drag-and-drop the `the-star-website` folder (or connect a Git repo
   containing it).
3. Set the custom domain (e.g. `thestarmodular.in`) in the host's
   dashboard and follow their DNS instructions.

**Option B — Any traditional web host (cPanel, etc.)**
1. Upload the entire contents of `the-star-website/` (not the folder
   itself — its *contents*) into your hosting account's `public_html`
   (or equivalent) directory via FTP/SFTP or the file manager.
2. Ensure `index.html` sits at the root.

**Option C — GitHub Pages**
1. Push the folder contents to a GitHub repository.
2. Enable GitHub Pages for that repository in Settings → Pages.

After deploying, update `SITE_URL` (see section 5) and regenerate if you
used the Python generator, or manually update the canonical/OG URLs if
editing HTML directly.

## 8. Regenerating the site (optional, for developers)

The site was built with a small Python static-site generator
(`generate.py` + `pages_*.py` + `build.py`) rather than hand-written
HTML, so structural changes (new pages, nav changes, design-system
updates) can be made once in the templates and regenerated everywhere.
This generator source is included in `/_generator-source/` for
reference — it is **not** needed to run the website and can be deleted
if you only want the static output. To regenerate:

```bash
cd _generator-source
python3 build.py     # writes into ../ (the site root)
```

Requires only Python 3 (no external packages).

## 9. Admin credentials / environment variables

Not applicable to this static build — there is no login and nothing to
configure to run it. These become relevant once the backend in section 4
is built; at that point, standard practice is an `.env` file (never
committed to Git) holding `DATABASE_URL`, `NEXTAUTH_SECRET`,
`ADMIN_EMAIL`/initial password (changed on first login), and storage
credentials.

---

Questions about anything in this package — where a specific fact came
from, why a page is structured the way it is, or how to extend it —
are answered by the source files themselves: everything is plain HTML/
CSS/JS with no obfuscation or minification.
